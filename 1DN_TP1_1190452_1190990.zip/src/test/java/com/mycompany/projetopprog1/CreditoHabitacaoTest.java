/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.projetopprog1;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Utilizador
 */

/**
 *
 * @author Massas
 */
public class CreditoHabitacaoTest {

    @Test
    public void testCalcularMontanteAReceberPorCadaCredito() {
        System.out.println("calcularMontanteAReceberPorCadaCredito");
        CreditoHabitacao instance = new CreditoHabitacao(null, null, 120000, 240, 1);
        double expResult = 133255;
        double result = instance.calcularMontanteARecaberPorCadaCredito();
        assertEquals(expResult, result, 0.01);
    }

    /**
     * Test of calcularMontanteTotalJuros method, of class CreditoHabitacao.
     */
    @Test
    public void testCalcularMontanteTotalJuros() {
        System.out.println("calcularMontanteTotalJuros");
        CreditoHabitacao instance = new CreditoHabitacao(null, null, 120000, 240, 1);
        double expResult = 13255;
        double result = instance.calcularMontanteTotalJuros();
        assertEquals(expResult, result, 0.01);

    }
    
}
