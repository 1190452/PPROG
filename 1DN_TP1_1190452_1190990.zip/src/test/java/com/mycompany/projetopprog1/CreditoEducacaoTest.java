
package com.mycompany.projetopprog1;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Massas
 */
public class CreditoEducacaoTest {
    
    @Test
    public void testCalcularMontanteARecaberPorCadaCredito() {
        System.out.println("calcularMontanteARecaberPorCadaCredito");
        CreditoEducacao instance = new CreditoEducacao(null, null, 18000, 60, 24);
        double expResult = 19275;
        double result = instance.calcularMontanteARecaberPorCadaCredito();
        assertEquals(expResult, result, 0.01);
    }

    /**
     * Test of calcularMontanteTotalJuros method, of class CreditoEducacao.
     */
    @Test
    public void testCalcularMontanteTotalJuros() {
        System.out.println("calcularMontanteTotalJuros");
        CreditoEducacao instance = new CreditoEducacao(null, null, 18000, 60, 24);
        double expResult = 1275;
        double result = instance.calcularMontanteTotalJuros();
        assertEquals(expResult, result, 0.01);
    }

   
 
    
}
