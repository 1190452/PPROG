package com.mycompany.projetopprog1;

/**
 * Representa um crédito bancário através do seu nome, da sua profissão, montante de financiamento, prazo de Financiamento, spread e taxa Euribor assoiada ao crédito.
 * 
 * @author Bruno Pereira
 */
public class CreditoHabitacao extends CreditoBancario {
    /**
     * O spred acordado entre o cliente e a instituição bancária.
     */
    private double spread;
    
    /**
     * Taxa Euribor associada ao crédito Habitação.
     */
    private static double taxaEuribor = 0.1;
    
    /**
     * O spred acordado entre o cliente e a instituição bancária por omissao.
     */
    private static final double Spread_Omissao=0;
    
    /**
     * A quantidade de Creditos de Habitação criados.
     */
    private static int qtdCreditoHabitacao = 0;
    
    /**
     * Constrói uma instância do Crédito Consumo recebendo o nome, a profissão, o montante de financiamento e o prazo de financiamento.
     *
     * @param nome o nome do cliente
     * @param profissao profissao do cliente
     * @param montante montante de financiamento que o cliente necessita.
     * @param prazoFinanciamento O prazo de financiamento que o cliente tem para abater a dívida.
     * @param spread acordado entre o cliente e a instituição bancária por omissao.
     */
    public CreditoHabitacao (String nomeCliente, String profissao,double montante,int prazoFinanciamento, double spread){
        super(nomeCliente, profissao, montante, prazoFinanciamento);
        this.spread=spread;
        qtdCreditoHabitacao++;
    }
    
    /**
     * Constrói uma instância do Crédito Consumo recebendo o nome, a profissão, o montante de financiamento, o prazo de financiamento e o spread por omissão.
     */
    public CreditoHabitacao(){
        super();
        spread = Spread_Omissao;
        qtdCreditoHabitacao++;
    }

    /**
     * @return the spread
     */
    public double getSpread() {
        return spread;
    }

    /**
     * @param spread the spread to set
     */
    public void setSpread(double spread) {
        this.spread = spread;
    }

    /**
     * @return the taxaEuribor
     */
    public static double getTaxaEuribor() {
        return taxaEuribor;
    }

    /**
     * @param aTaxaEuribor the taxaEuribor to set
     */
    public static void setTaxaEuribor(double aTaxaEuribor) {
        taxaEuribor = aTaxaEuribor;
    }

    /**
     * @return the qtdCreditoHabitacao
     */
    public static int getQtdCreditoHabitacao() {
        return qtdCreditoHabitacao;
    }
    
    /**
     * @param aQtdCreditoHabitacao the qtdCreditoHabitacao to set
     */
    public static void setQtdCreditoHabitacao(int aQtdCreditoHabitacao) {
        qtdCreditoHabitacao = aQtdCreditoHabitacao;
    }

    /**
     * Devolve os juros associados ao crédito bancário.
     *
     * @return juros
     */
    @Override
    public double calcularMontanteTotalJuros(){
        double prestMensalsemJuros = getMontante()/getPrazoFinanciamento();
        double valorDivida = getMontante();
        double totalJuros = 0;
        double juros;
        for(int i = 0; i<getPrazoFinanciamento(); i++) {
            juros = valorDivida * ((taxaEuribor/100/12)+((spread/100)/12));
            valorDivida = valorDivida - prestMensalsemJuros;
            totalJuros=totalJuros + juros;
        }
        return totalJuros;
    }
    
    /**
     * Devolve o valor total a pagar pelo cliente à instituição bancária.
     *
     * @return valor total a pagar
     */
    @Override
    public double calcularMontanteARecaberPorCadaCredito() {
        double prestMensalsemJuros = getMontante()/getPrazoFinanciamento();
        double juros, prestMensal;
        double valorDivida = getMontante();
        double totalMontante = 0;
        for(int i = 0; i<getPrazoFinanciamento(); i++) {
            juros = valorDivida * ((taxaEuribor/100/12)+((spread/100)/12));
            prestMensal = prestMensalsemJuros + juros;
            valorDivida = valorDivida - prestMensalsemJuros;
            totalMontante=totalMontante+prestMensal;
        }
        return totalMontante;
    }
    
    /**
     * Devolve a descrição textual do Credito à Habitação.
     *
     * @return caraterísticas do Crédito Habitação.
     */
    @Override
    public String toString(){
        return String.format("Crédito à Habitação: %n%s  %nSpread = %.2f ", super.toString(), getSpread());
    }

}
