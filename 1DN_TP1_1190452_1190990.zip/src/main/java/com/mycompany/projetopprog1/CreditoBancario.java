package com.mycompany.projetopprog1;
/**
 * Esta classe permite a construção de uma hierarquia de classes para
 * representarem diferentes tipos de créditos bancários. Especifica membros 
 * comuns a todas as classes da hierarquia.
 *
 * @author Bruno Pereira
 */
public abstract class CreditoBancario {
    /**
     * O nome do cliente.
     */
    private String nomeCliente;
    
     /**
     * A profissão do cliente.
     */
    private String profissao;
    
     /**
     * O montante de financiamento que o cliente necessita.
     */
    private double montante;
    
    /**
     * O prazo de financiamento que o cliente tem para abater a dívida.
     */
    private int prazoFinanciamento;
    
    /**
     * O nome por omissão do cliente.
     */
    private static String NOME_POR_OMISSAO="sem nome";
    
    /**
     * A profissão por omissão do cliente.
     */
    private static String PROFISSAO_POR_OMISSAO="sem profissão";
    
    /**
     * O montante de financiamento por omissao do cliente.
     */
    private static float MONTANTE_POR_OMISSAO=0;
    
    /**
     * O prazo de financiamento por omissão do cliente.
     */
    private static int PRAZO_POR_OMISSAO=0;
    
    /**
     * Inicializa o nome do cliente com a sua profissão, o montante de empréstomo e o prazo de financiamento.
     *
     * @param nome o nome do cliente
     * @param profissao profissao do cliente
     * @param montante montante de financiamento que o cliente necessita.
     * @param prazoFinanciamento O prazo de financiamento que o cliente tem para abater a dívida.
     */
    public CreditoBancario(String nomeCliente, String profissao,double montante,int prazoFinanciamento){
        this.nomeCliente=nomeCliente;
        this.profissao=profissao;
        this.montante=montante;
        this.prazoFinanciamento=prazoFinanciamento;
    }
    
    /**
     * Inicializa o nome do cliente com a sua profissão, o montante de empréstomo e o prazo de financiamento por omissão.
     */
    public CreditoBancario(){
        nomeCliente=NOME_POR_OMISSAO;
        profissao=PROFISSAO_POR_OMISSAO;
        montante=MONTANTE_POR_OMISSAO;
        prazoFinanciamento=PRAZO_POR_OMISSAO;   
    }

    /**
     * @return the nomeCliente
     */
    public String getNomeCliente() {
        return nomeCliente;
    }

    /**
     * @param nomeCliente the nomeCliente to set
     */
    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    /**
     * @return the profissao
     */
    public String getProfissao() {
        return profissao;
    }

    /**
     * @param profissao the profissao to set
     */
    public void setProfissao(String profissao) {
        this.profissao = profissao;
    }

    /**
     * @return the montante
     */
    public double getMontante() {
        return montante;
    }

    /**
     * @param montante the montante to set
     */
    public void setMontante(double montante) {
        this.montante = montante;
    }

    /**
     * @return the prazoFinanciamento
     */
    public int getPrazoFinanciamento() {
        return prazoFinanciamento;
    }

    /**
     * @param prazoFinanciamento the prazoFinanciamento to set
     */
    public void setPrazoFinanciamento(int prazoFinanciamento) {
        this.prazoFinanciamento = prazoFinanciamento;
    }
    
    /**
     * Devolve a descrição textual do crédito bancário com o seu nome, profissão, montante e prazo de financiamento.
     *
     * @return caraterísticas do crédito bancário.
     */
    @Override
    public String toString(){
        return String.format("Nome: %s \nProfissao: %s \nMontente: %.2f \nPrazo De Financiamento: %d",nomeCliente,profissao,montante,prazoFinanciamento);
    }
    
    /**
     * Permite  a obtenção do valor total a pagar pelo cliente através do polimorfismo.
     *
     * @return vencimento do trabalhador
     */
   public abstract double calcularMontanteARecaberPorCadaCredito();
   
   /**
     * Permite a obtenção dos juros do cliente através do polimorfismo.
     *
     * @return vencimento do trabalhador
     */
   public abstract double calcularMontanteTotalJuros();     
}
