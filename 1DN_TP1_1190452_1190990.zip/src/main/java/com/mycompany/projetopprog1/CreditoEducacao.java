package com.mycompany.projetopprog1;
/**
 * Representa um crédito bancário através do seu nome, da sua profissão, montante de financiamento, prazo de Financiamento, periodo de carência e uma taxa de juro anual.
 * 
 * @author Bruno Pereira
 */
public class CreditoEducacao extends CreditoConsumo {
    /**
     * Periodo de Carência em que o Cliente apenas paga os juros à instituição bancária.
     */
    private int periodoCarencia;
    /**
     * Periodo de Carência em que o Cliente apenas paga os juros à instituição bancária por omissão.
     */
    private static final int CARENCIA_POR_OMISSAO=0; 
    
    /**
     * Taxa Anual associada ao Crédito Educação.
     */
    private static double taxaJuroAnual=0.02;
    
       
    /**
     * Constrói uma instância do Crédito Consumo recebendo o nome, a profissão, o montante de financiamento e o prazo de financiamento.
     *
     * @param nome o nome do cliente
     * @param profissao profissao do cliente
     * @param montante montante de financiamento que o cliente necessita.
     * @param prazoFinanciamento O prazo de financiamento que o cliente tem para abater a dívida.
     * @param periodoCarencia periodo de Carência em que o Cliente apenas paga os juros à instituição bancária por omissão.
     */
    public CreditoEducacao(String nomeCliente, String profissao,double montante,int prazoFinanciamento,int periodoCarencia){
        super(nomeCliente,profissao,montante,prazoFinanciamento);
        this.periodoCarencia=periodoCarencia;               
    }    
    
    /**
     * Constrói uma instância do Crédito Consumo recebendo o nome, a profissão, o montante de financiamento, o prazo de financiamento e o periodo de carência por omissao.
     */
    public CreditoEducacao(){
        super();        
        periodoCarencia=CARENCIA_POR_OMISSAO;
    }
    
     /**
     * @return the taxaJuroAnual
     */
    public static double getTaxaJuroAnual() {
        return taxaJuroAnual;
    }
    
    /**
     * @param aTaxaJuroAnual the taxaJuroAnual to set
     */
    public static void setTaxaJuroAnual(double aTaxaJuroAnual) {
        taxaJuroAnual = aTaxaJuroAnual;
    }

    /**
     * @return the periodoCarencia
     */
    public int getPeriodoCarencia() {
        return periodoCarencia;
    }

    /**
     * @param periodoCarencia the periodoCarencia to set
     */
    public void setPeriodoCarencia(int periodoCarencia) {
        this.periodoCarencia = periodoCarencia;
    }
    
    /**
     * Devolve o valor total a pagar pelo cliente à instituição bancária.
     *
     * @return valor total a pagar
     */
    @Override
    public double calcularMontanteARecaberPorCadaCredito(){
        double amortCapital = getMontante()/(getPrazoFinanciamento()-periodoCarencia);
        double divida = getMontante();
        double juros, totalJuros=0, valorReceber=0, prestMensal;
        for (int i = 0; i < periodoCarencia; i++) {
            juros = divida * (taxaJuroAnual/12);
            totalJuros=totalJuros+juros;
        }
        valorReceber = totalJuros;
        for (int i = periodoCarencia; i < getPrazoFinanciamento(); i++) {
            juros= divida*(taxaJuroAnual/12);
            prestMensal =  amortCapital + juros;
            divida = divida - amortCapital;
            valorReceber = valorReceber + prestMensal;
        }
        return valorReceber;
    }
    
    /**
     * Devolve os juros associados ao crédito bancário.
     *
     * @return juros
     */
    @Override
    public double calcularMontanteTotalJuros(){
        double amortCapital = getMontante()/(getPrazoFinanciamento()-periodoCarencia);
        double divida = getMontante();
        double juros, totalJuros=0;
        for (int i = 0; i < periodoCarencia; i++) {
            juros = divida * (taxaJuroAnual/12);
            totalJuros=totalJuros+juros;
        }
        for (int i = periodoCarencia; i<getPrazoFinanciamento(); i++) {  
            juros = divida * (taxaJuroAnual / 12);            
            divida = divida-amortCapital;
            totalJuros=totalJuros + juros;            
        }        
        return totalJuros;
    }
    
    /**
     * Devolve a descrição textual do Credito à Educação.
     *
     * @return caraterísticas do Crédito Educação.
     */
    @Override
    public String toString(){
        return String.format("Credito Educação: %n%s %nPeriodo de Carência: %d",super.toString(), getPeriodoCarencia());
    }

   
}
