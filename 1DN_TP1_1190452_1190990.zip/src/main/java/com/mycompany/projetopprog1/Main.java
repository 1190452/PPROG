/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.projetopprog1;

/**
 *
 * @author Massas
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CreditoHabitacao b1 = new CreditoHabitacao ("Bruno", "Engenheiro Informático", 300000, 240, 1);
        CreditoHabitacao b2 = new CreditoHabitacao ("José", "Engenheiro Mecanico", 135000, 240, 1);
        CreditoAutomovel a1 = new CreditoAutomovel ("Rodrigo", "Empresário", 30000, 20);
        CreditoAutomovel a2 = new CreditoAutomovel ("Miguel", "Bancário", 150000, 240);
        CreditoEducacao e1 = new CreditoEducacao ("Antonio", "Eletrecista", 15000, 60, 24);
        CreditoEducacao e2 = new CreditoEducacao ("Maria", "Gestora", 18000, 60, 24);
        
        CreditoBancario [] contentor = new CreditoBancario [20];
        contentor [0] = b1;
        contentor [1] = b2;
        contentor [2] = a1;
        contentor [3] = a2;
        contentor [4] = e1;
        contentor [5] = e2;
        
        System.out.println("Listagem dos nomes dos clientes e os valores que a instituição bancária irá receber até ao final de cada contrato de crédito ao consumo realizado:");
        for(int i=0; i<contentor.length; i++){
            if(contentor[i]!=null){
                System.out.printf("%nValor a receber pelo cliente %s: %.2f euros", contentor[i].getNomeCliente(), (float) contentor[i].calcularMontanteARecaberPorCadaCredito());
            }
    }
        System.out.println("");
        System.out.println("\nListagem dos nomes dos clientes e os valores dos juros que a instituição bancária irá receber até ao final de cada contrato de crédito ao consumo realizado:");   
        for(int i=0; i<contentor.length; i++){
            if(contentor[i]!=null){
                System.out.printf("%nValor a receber pelo cliente %s: %.2f euros", contentor[i].getNomeCliente(), (float)contentor[i].calcularMontanteTotalJuros());
            }
        }
        System.out.println("");
        System.out.println("\nForam criadas " + CreditoHabitacao.getQtdCreditoHabitacao() + " instâncias de créditos à habitação");     
        System.out.println("Foram criadas " + CreditoConsumo.getQtdCreditosConsumo()+ " instâncias de crédito de consumo");
        
        double valorTotal = 0, valorTotalJuros=0;
        System.out.println("\nCálculo e apresentação do valor total e dos respetivos juros que a instituição bancária irá receber:");   
        for(int i=0; i<contentor.length; i++){
            if(contentor[i]!=null){
               valorTotal = valorTotal + contentor[i].calcularMontanteARecaberPorCadaCredito();
               valorTotalJuros = valorTotalJuros + contentor[i].calcularMontanteTotalJuros();
            }
        }
        System.out.printf("Valor Total a receber pelos créditos bancários realizados: %.2f", valorTotal);
        System.out.printf("%nValor Total de Juros a receber pelos créditos bancários realizados: %.2f", valorTotalJuros);
    }   
}
    

