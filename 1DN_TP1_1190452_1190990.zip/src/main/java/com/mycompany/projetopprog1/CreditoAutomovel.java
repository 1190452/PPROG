
package com.mycompany.projetopprog1;

/**
 * Representa um crédito bancário através do seu nome, da sua profissão, montante de financiamento, prazo de Financiamento.
 * 
 * @author Ricardo Pereira
 */
public class CreditoAutomovel extends CreditoConsumo{
    
    /**
     * Taxa Anual associada ao crédito Automóvel.
     */
   private static double taxaJuroAnual = 0.06; 
   
   /**
     * Taxa de Desconto associada ao crédito Automóvel caso o prazo de financiamento seja inferior ou igual a 24 meses.
     */
   private static double taxaDesconto = 0.01;
   
   /**
     * Prazo de financimanto limite para obter a taxa de desconto.
     */
   private static int financiamentoLimite = 24;
   
   /**
     * Constrói uma instância do Crédito Consumo recebendo o nome, a profissão, o montante de financiamento e o prazo de financiamento.
     *
     * @param nome o nome do cliente
     * @param profissao profissao do cliente
     * @param montante montante de financiamento que o cliente necessita.
     * @param prazoFinanciamento O prazo de financiamento que o cliente tem para abater a dívida.
     */
   public CreditoAutomovel (String nomeCliente, String profissao,double montante,int prazoFinanciamento){
     super(nomeCliente, profissao, montante, prazoFinanciamento);
   }
   
   /**
     * Constrói uma instância do Crédito Consumo recebendo o nome, a profissão, o montante de financiamento, o prazo de financiamento e o spread por omissão.
     */
   public CreditoAutomovel(){
       super();
   }
      /**
     * @return the taxaJuroAnual
     */
    public static double getTaxaJuroAnual() {
        return taxaJuroAnual;
    }

    /**
     * @param aTaxaJuroAnual the taxaJuroAnual to set
     */
    public static void setTaxaJuroAnual(double aTaxaJuroAnual) {
        taxaJuroAnual = aTaxaJuroAnual;
    }

    /**
     * @return the taxaDesconto
     */
    public static double getTaxaDesconto() {
        return taxaDesconto;
    }

    /**
     * @param aTaxaDesconto the taxaDesconto to set
     */
    public static void setTaxaDesconto(double aTaxaDesconto) {
        taxaDesconto = aTaxaDesconto;
    }

    /**
     * @return the financiamentoLimite
     */
    public static int getFinanciamentoLimite() {
        return financiamentoLimite;
    }

    /**
     * @param aFinanciamentoLimite the financiamentoLimite to set
     */
    public static void setFinanciamentoLimite(int aFinanciamentoLimite) {
        financiamentoLimite = aFinanciamentoLimite;
    }
    
    /**
     * Devolve os juros associados ao crédito bancário.
     *
     * @return juros
     */
   @Override
   public double  calcularMontanteTotalJuros(){
        double prestMensalsemJuros = getMontante()/getPrazoFinanciamento();
        double valorDivida = getMontante();
        double totalJuros = 0;
        double juros;
        for(int i = 0; i<getPrazoFinanciamento(); i++) {
            juros = getPrazoFinanciamento()<=getFinanciamentoLimite() ? valorDivida * (getTaxaJuroAnual()/12) * (1-taxaDesconto) : valorDivida * (getTaxaJuroAnual()/12);
            valorDivida = valorDivida - prestMensalsemJuros;
            totalJuros=totalJuros + juros;
        }
        return totalJuros;
    }
   
   /**
     * Devolve o valor total a pagar pelo cliente à instituição bancária.
     *
     * @return valor total a pagar
     */
    @Override
    public double calcularMontanteARecaberPorCadaCredito() {
       double prestMensalsemJuros = getMontante()/getPrazoFinanciamento();
        double juros, prestMensal;
        double valorDivida = getMontante();
        double totalMontante = 0;
        for(int i = 0; i<getPrazoFinanciamento(); i++) {
            juros = valorDivida * (getTaxaJuroAnual()/12);
            prestMensal = getPrazoFinanciamento()<=getFinanciamentoLimite() ? (prestMensalsemJuros + juros)* (1-taxaDesconto) : prestMensalsemJuros + juros;
            valorDivida = valorDivida - prestMensalsemJuros;
            totalMontante=totalMontante+prestMensal;
        }
        return totalMontante;
    }
    
    /**
     * Devolve a descrição textual do Credito Automóvel.
     *
     * @return caraterísticas do Credito Automóvel.
     */
   @Override
    public String toString(){
        return String.format("Crédito Automóvel: %n%s", super.toString());
    }

 }
