
package com.mycompany.projetopprog1;
/**
 * Representa um crédito bancário através do seu nome, da sua profissão, montante de financiamento e prazo de Financiamento.
 * 
 * @author Ricardo Pereira
 */
public abstract class CreditoConsumo extends CreditoBancario{
    /**
     * A quantidade de Creditos de Consumo criados.
     */
    private static int qtdCreditosConsumo = 0;
    
    /**
     * Constrói uma instância do Crédito Consumo recebendo o nome, a profissão, o montante de financiamento e o prazo de financiamento.
     *
     * @param nome o nome do cliente
     * @param profissao profissao do cliente
     * @param montante montante de financiamento que o cliente necessita.
     * @param prazoFinanciamento O prazo de financiamento que o cliente tem para abater a dívida.
     */
    public CreditoConsumo(String nomeCliente, String profissao,double montante,int prazoFinanciamento ){
         super(nomeCliente, profissao, montante, prazoFinanciamento);
         qtdCreditosConsumo++;
    }
    
    /**
     * Constrói uma instância do Crédito Consumo recebendo o nome, a profissão, o montante de financiamento e o prazo de financiamento por omissão.
     */
     public CreditoConsumo(){
        super(); 
        qtdCreditosConsumo++;
     }

    /**
     * @return the qtdCreditosConsumo
     */
    public static int getQtdCreditosConsumo() {
        return qtdCreditosConsumo;
    }

    /**
     * @param aQtdCreditosConsumo the qtdCreditosConsumo to set
     */
    public static void setQtdCreditosConsumo(int aQtdCreditosConsumo) {
        qtdCreditosConsumo = aQtdCreditosConsumo;
    }

    /**
     * Permite  a obtenção do valor total a pagar pelo cliente através do polimorfismo.
     *
     * @return vencimento do trabalhador
     */
    @Override
   public abstract double calcularMontanteARecaberPorCadaCredito();
   
   /**
     * Permite a obtenção dos juros do cliente através do polimorfismo.
     *
     * @return vencimento do trabalhador
     */
    @Override
    public abstract double calcularMontanteTotalJuros(); 
   
}
