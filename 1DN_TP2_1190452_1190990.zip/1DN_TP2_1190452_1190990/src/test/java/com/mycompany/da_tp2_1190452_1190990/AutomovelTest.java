/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.da_tp2_1190452_1190990;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Massas
 */
public class AutomovelTest {
    
   
    /**
     * Test of CalcularValorVenda method, of class Automovel.
     */
    @Test
    public void testCalcularValorVenda() {
        System.out.println("CalcularValorVenda");
        Automovel instance = new Automovel("null", "null", 30000, 100);
        double expResult = 30900;
        double result = instance.CalcularValorVenda();
        assertEquals(expResult, result, 0.01);
    }
    /**
     * Test of CalcularValorVenda method, of class Automovel.
     */
    @Test
    public void testCalcularValorVenda1() {
        System.out.println("CalcularValorVenda");
        Automovel instance = new Automovel("null", "null", 10000, 50);
        double expResult = 10300;
        double result = instance.CalcularValorVenda();
        assertEquals(expResult, result, 0.01);
    }

    /**
     * Test of CalcularValorAluguer method, of class Automovel.
     */
    @Test
    public void testCalcularValorAluguer() {
        System.out.println("CalcularValorAluguer");
        Automovel instance = new Automovel("null", "null", 30000, 100);
        double expResult = 105;
        double result = instance.CalcularValorAluguer();
        assertEquals(expResult, result, 0.01);
    }
    /**
     * Test of CalcularValorAluguer method, of class Automovel.
     */
    @Test
    public void testCalcularValorAluguer2() {
        System.out.println("CalcularValorAluguer");
        Automovel instance = new Automovel("null", "null", 45000, 300);
        double expResult = 315;
        double result = instance.CalcularValorAluguer();
        assertEquals(expResult, result, 0.01);
    }
}
