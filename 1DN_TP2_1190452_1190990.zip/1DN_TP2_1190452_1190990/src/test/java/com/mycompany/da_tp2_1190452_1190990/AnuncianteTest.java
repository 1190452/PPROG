/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.da_tp2_1190452_1190990;

import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Massas
 */
public class AnuncianteTest {
    
  public void testAddListaAlugaveis() {
        Anunciante instance = new Anunciante("Nando", new Endereco("Rua 4", "4485-897", "Canelas"));
        instance.addListaAlugaveis(new Automovel("Audi", "A1", 45000, 1200));
        instance.addListaAlugaveis(new Apartamento("t4", new Endereco("Rua4", "4485-897", "canelas"), 450, 4500));
        instance.addListaAlugaveis(new Automovel("Audi", "A1", 45000, 1200));
        boolean expectedResult = false;
        boolean result = instance.addListaAlugaveis(new Automovel("Audi", "A1", 45000, 1200));
        assertEquals(expectedResult, result);
    }
        public void testAddListaVendaveis() {
        Anunciante instance = new Anunciante("Nando", new Endereco("Rua 4", "4485-897", "Canelas"));
        instance.addListaVendaveis(new Automovel("Audi", "A1", 45000, 1200));
        instance.addListaVendaveis(new Automovel("Audi", "A1", 45000, 1200));
        boolean result = instance.addListaVendaveis(new Automovel("Audi", "A1", 45000, 1200));
        assertEquals(false, result);
    }
    
}
