/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.da_tp2_1190452_1190990;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Massas
 */
public class TelemovelTest {
    /**
     * Test of CalcularValorVenda method, of class Telemovel.
     */
    @Test
    public void testCalcularValorVenda() {
        System.out.println("CalcularValorVenda");
        Telemovel instance = new Telemovel("null", 300);
        double expResult = 309;
        double result = instance.CalcularValorVenda();
        assertEquals(expResult, result, 0.01f);
    }
    @Test
    public void testCalcularValorVenda1() {
        System.out.println("CalcularValorVenda");
        Telemovel instance = new Telemovel("null", 600);
        double expResult = 618;
        double result = instance.CalcularValorVenda();
        assertEquals(expResult, result, 0.01f);
    }

    
}
