/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.da_tp2_1190452_1190990;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Massas
 */
public class ApartamentoTest {
    /**
     * Test of CalcularValorAluguer method, of class Apartamento.
     */
    @Test
    public void testCalcularValorAluguer() {
        System.out.println("CalcularValorAluguer");
        Apartamento instance = new Apartamento("null", new Endereco("null","null","null"),200,400);
        double expResult = 420;
        double result = instance.CalcularValorAluguer();
        assertEquals(expResult, result, 0.01);
    }
    /**
     * Test of CalcularValorAluguer method, of class Apartamento.
     */
    @Test
    public void testCalcularValorAluguer1() {
        System.out.println("CalcularValorAluguer");
        Apartamento instance = new Apartamento("null", new Endereco("null","null","null"),100,300);
        double expResult = 315;
        double result = instance.CalcularValorAluguer();
        assertEquals(expResult, result, 0.01);
    }
    /**
     * Test of CalcularValorAluguer method, of class Apartamento.
     */
    @Test
    public void testCalcularValorAluguer2() {
        System.out.println("CalcularValorAluguer");
        Apartamento instance = new Apartamento("null", new Endereco("null","null","null"),500,700);
        double expResult = 735;
        double result = instance.CalcularValorAluguer();
        assertEquals(expResult, result, 0.01);
    }

}
