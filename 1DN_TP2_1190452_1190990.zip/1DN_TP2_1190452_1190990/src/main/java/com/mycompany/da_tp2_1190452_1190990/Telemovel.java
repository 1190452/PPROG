
package com.mycompany.da_tp2_1190452_1190990;

/** 
 * Esta classe permite criar um Telemovel para ser vendido na plataforma.
 * 
 * @author Ricardo Pereira
 */
public class Telemovel implements Vendaveis{
    /**
     * A designação do telemovel.
     */
    private String designacao;

    /**
     * O valor de venda do telemovel.
     */
    private double valorVenda;
    
    /**
     * A designaçao por omissao.
     */
    private static final String DESIGNACAO_POR_OMISSAO="sem designação";

    /**
     * O valor de venda por omissao.
     */
    private static final double VALORVENDA_OMISSAO = 0;

    /**
     * A taxa fixa relativa à venda.
     */
    private static double taxaFixaVenda = 3;
    
    /**
     * Constrói uma instância do Telemovel recebendo a designacao e o valor de venda.
     *
     * @param designacao a designaçao do telemovel
     * @param valorVenda o valor de venda do telemovel
     */
    public Telemovel (String designacao, double valorVenda){
       this.designacao = designacao;
       this.valorVenda = valorVenda;
    }
    
    /**
     * Constrói uma instância do Telemovel recebendo a designacao e o valor de venda por omissao.
     */
    public Telemovel (){
        designacao = DESIGNACAO_POR_OMISSAO;
        valorVenda = VALORVENDA_OMISSAO;
    }

    /**
     * @return the designacao
     */
    public String getDesignacao() {
        return designacao;
    }

    /**
     * @param designacao the designacao to set
     */
    public void setDesignacao(String designacao) {
        this.designacao = designacao;
    }
    /**
     * @return the valorVenda
     */
    public double getValorVenda() {
        return valorVenda;
    }

    /**
     * @param valorVenda the valorVenda to set
     */
    public void setValorVenda(double valorVenda) {
        this.valorVenda = valorVenda;
    }

    /**
     * @return the taxaFixaVenda
     */
    public static double getTaxaFixaVenda() {
        return taxaFixaVenda;
    }

    /**
     * @param aTaxaFixaVenda the taxaFixaVenda to set
     */
    public static void setTaxaFixaVenda(double aTaxaFixaVenda) {
        taxaFixaVenda = aTaxaFixaVenda;
    }

    /**
     * Permite  a obtenção do valor de venda através de uma interface.
     *
     * @return valor de venda com a taxa aplicada
     */
    @Override
    public double CalcularValorVenda() {
        return getValorVenda() * (1 + (getTaxaFixaVenda()/100));   
    }

    /**
     * Devolve a descrição textual do Telemovel com a sua designaçao.
     *
     * @return caracteristicas do telemovel
     */
    @Override
    public String toString(){
        return String.format("Telemóvel %s",designacao);
    }

    

  
    
    
    
}
