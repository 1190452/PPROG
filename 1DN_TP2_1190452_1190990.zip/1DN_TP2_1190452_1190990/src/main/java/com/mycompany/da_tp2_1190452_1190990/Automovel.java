/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.da_tp2_1190452_1190990;

/** 
 * Esta classe permite criar um automovel de forma a que o anunciante o possa alugar ou vender.
 * 
 * @author Ricardo Pereira
 */
public class Automovel implements Alugaveis, Vendaveis{
    /**
     * A marca do automovel.
     */
    private String marca;

    /**
     * O modelo do automovel.
     */
    private String modelo;

    /**
     * O valor de venda do automovel.
     */
    private double valorVenda;

    /**
     * O valor de aluguer do automovel.
     */
    private double valorAluguer;
    
    /**
     * A marca por omissão.
     */
    private static final String MARCA_POR_OMISSAO="sem marca";

    /**
     * O modelo por omissão.
     */
    private static final String MODELO_POR_OMISSAO="sem modelo";

    /**
     * O valor de venda por omissão.
     */
    private static final double VALORVENDA_OMISSAO = 0;

    /**
     * O valor de aluguer por omissão.
     */
    private static final double VALORALUGUER_OMISSAO = 0;
    
    /**
     * A taxa fixa relativa à venda.
     */
    private static double taxaFixaVenda = 3;

    /**
     * A taxa fixa relativa ao aluguer.
     */
    private static double taxaFixaAluguer = 5;
    
    /**
     * Constrói uma instância do Automovel recebendo a marca, o modelo, o valor de venda e o valor de aluguer.
     *
     * @param marca a marca do automovel
     * @param modelo o modelo do automovel
     * @param valorVenda o valor de venda do automovel
     * @param valorAluguer o valor de aluguer do automovel
     */
    public Automovel (String marca, String modelo, double valorVenda, double valorAluguer){
        this.marca = marca;
        this.modelo = modelo;
        this.valorVenda = valorVenda;
        this.valorAluguer = valorAluguer;
    }
    
    /**
     * Constrói uma instância do Automovel recebendo a marca, o modelo, o vlaor de venda e o valor de aluguer por omissão
     */
    public Automovel (){
        marca = MARCA_POR_OMISSAO;
        modelo = MODELO_POR_OMISSAO;
        valorVenda = VALORVENDA_OMISSAO;
        valorAluguer = VALORALUGUER_OMISSAO;
    }

    /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @param marca the marca to set
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    

    /**
     * @return the valorVenda
     */
    public double getValorVenda() {
        return valorVenda;
    }

    /**
     * @param valorVenda the valorVenda to set
     */
    public void setValorVenda(double valorVenda) {
        this.valorVenda = valorVenda;
    }

    /**
     * @return the valorAluguer
     */
    public double getValorAluguer() {
        return valorAluguer;
    }

    /**
     * @param valorAluguer the valorAluguer to set
     */
    public void setValorAluguer(double valorAluguer) {
        this.valorAluguer = valorAluguer;
    }

    /**
     * @return the taxaFixaVenda
     */
    public static double getTaxaFixaVenda() {
        return taxaFixaVenda;
    }

    /**
     * @param aTaxaFixaVenda the taxaFixaVenda to set
     */
    public static void setTaxaFixaVenda(double aTaxaFixaVenda) {
        taxaFixaVenda = aTaxaFixaVenda;
    }

    /**
     * @return the taxaFixaAluger
     */
    public static double getTaxaFixaAluguer() {
        return taxaFixaAluguer;
    }

    /**
     * @param aTaxaFixaAluger the taxaFixaAluger to set
     */
    public static void setTaxaFixaAluguer(double aTaxaFixaAluger) {
        taxaFixaAluguer = aTaxaFixaAluger;
    }
    
    /**
     * Permite  a obtenção do valor de venda através de uma interface.
     *
     * @return valor de venda com a taxa aplicada
     */
    @Override
    public double CalcularValorVenda() {
       return getValorVenda() * (1 + (getTaxaFixaVenda()/100));
    }
    
    /**
     * Permite  a obtenção do valor de aluguer através de uma interface.
     *
     * @return valor de aluguer com a taxa aplicada
     */
    @Override
    public double CalcularValorAluguer() {
       return getValorAluguer() * (1 + (getTaxaFixaAluguer()/100));
    }

    /**
     * Devolve a descrição textual do automovel com a sua marca e o seu modelo.
     *
     * @return caracteristicas do automovel
     */
    @Override
    public String toString(){
        return String.format("Automóvel %s %s", marca,modelo);
    }    
}
