
package com.mycompany.da_tp2_1190452_1190990;

/** 
 * Esta classe permite criar um endereço tanto para o anunciante como para um apartamento.
 * 
 * @author Ricardo Pereira
 */
public class Endereco {
    /**
     * O nome da rua do endereço.
     */
    private String nomeRua;
    
    /**
     * O codigo postal do endereço.
     */
    private String codigoPostal;

    /**
     * A localidade do endereço.
     */
    private String localidade;
    
    /**
     * O nome da rua por omissão.
     */
    private static final String NOMERUA_POR_OMISSAO="sem nomme da rua";

    /**
     * O codigo postal por omissão.
     */
    private static final String CODIGO_POR_OMISSAO ="sem codigo";

    /**
     * A localidade por omissão.
     */
    private static final String LOCALIDADE_POR_OMISSAO="sem localidade";
    
    /**
     * Constrói uma instância do Endereco recebendo o nome da rua, o codigo postal e a localidade.
     *
     * @param nomeRua nome da rua do endereço
     * @param codigoPostal o codigo postal do endereço
     * @param localidade  a localidade do endereço
     */
    public Endereco(String nomeRua, String codigoPostal, String localidade){
        this.nomeRua = nomeRua;
        this.codigoPostal = codigoPostal;
        this.localidade = localidade;
    }

    /**
     * Constrói uma cópia da instancia Endereco criada
     */
    public Endereco(Endereco outroEndereco) {
        this.nomeRua = outroEndereco.nomeRua;
        this.codigoPostal = outroEndereco.codigoPostal;
        this.localidade = outroEndereco.localidade;
    }
    
    /**
     * Constrói uma instância do Endereco recebendo o nome da rua, o codigo postal e a localidade por omissao
     */
    public Endereco() {
        nomeRua =  NOMERUA_POR_OMISSAO;
        codigoPostal = CODIGO_POR_OMISSAO;
        localidade = LOCALIDADE_POR_OMISSAO;
    }

    /**
     * @return the nomeRua
     */
    public String getNomeRua() {
        return nomeRua;
    }

    /**
     * @param nomeRua the nomeRua to set
     */
    public void setNomeRua(String nomeRua) {
        this.nomeRua = nomeRua;
    }

    /**
     * @return the codigoPostal
     */
    public String getCodigoPostal() {
        return codigoPostal;
    }

    /**
     * @param codigoPostal the codigoPostal to set
     */
    public void setCodigoPostal(String codigoPostal) {
        this.codigoPostal = codigoPostal;
    }

    /**
     * @return the localidade
     */
    public String getLocalidade() {
        return localidade;
    }

    /**
     * @param localidade the localidade to set
     */
    public void setLocalidade(String localidade) {
        this.localidade = localidade;
    }
    
    /**
     * Devolve a descrição textual do endereço com o nome da rua, codigo postal e localidade.
     *
     * @return caracteristicas do endereco
     */
    public String toString(){
        return String.format("%s, %s, %s", nomeRua, codigoPostal, localidade);
    }
    
    
}
