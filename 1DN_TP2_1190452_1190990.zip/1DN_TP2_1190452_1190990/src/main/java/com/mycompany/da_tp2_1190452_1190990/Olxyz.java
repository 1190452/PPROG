/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.da_tp2_1190452_1190990;

/**
 *
 * @author Massas
 */
public class Olxyz {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //1
        Anunciante[] array = new Anunciante[5];

        //2
        Anunciante a1 = new Anunciante("Bruno", new Endereco("Rua de Ervilhaca", "4500-203", "Espinho"));
        Telemovel t1 = new Telemovel("iPhone 6", 300);
        Apartamento ap1 = new Apartamento("T3", new Endereco("Rua 14", "4500-300", "Espinho"), 245, 100);
        Automovel c1 = new Automovel("Mercedes", "AMG", 90000, 1500);
        array[0] = a1;
        array[0].addListaVendaveis(t1);
        array[0].addListaAlugaveis(ap1);
        array[0].addListaAlugaveis(c1);
        //3
        Anunciante a2 = new Anunciante("Ricardo", new Endereco("Rua 19", "4500-234", "Espinho"));
        Automovel c2 = new Automovel("Mini Cooper", "S", 7500, 237);
        Telemovel t2 = new Telemovel("iPhone X", 900);
        Apartamento ap2 = new Apartamento("T2", new Endereco("Rua 45", "4604-466", "Granja"), 500, 60);
        array[1] = a2;
        array[1].addListaVendaveis(c2);
        array[1].addListaVendaveis(t2);
        array[1].addListaAlugaveis(ap2);
        //4
        Anunciante a3 = new Anunciante("Rui", new Endereco("Rua 34", "4594-458", "Porto"));
        Apartamento ap3 = new Apartamento("T1", new Endereco("Rua 36", "4450-344", "Matosinhos"), 100, 30);
        Apartamento ap4 = new Apartamento("T4", new Endereco("Rua 54", "4592-300", "Lisboa"), 200, 40);
        array[2] = a3;
        array[2].addListaAlugaveis(ap3);
        array[2].addListaAlugaveis(ap4);

        //5
        int qtdProdutosAlugaveis = 0;
        for (Anunciante anunciante : array) {
            if (anunciante != null) {
                qtdProdutosAlugaveis += anunciante.getQuantidadeProdutosAlugaveis();
            }
        }
        System.out.println("A quantidade de artigos disponíveis para aluguer na plataforma Olxyz é igual a: " + qtdProdutosAlugaveis);

        //6
        System.out.println("\n##Visualizar, para cada Anunciante que publicita vendas, o respetivo nome, endereco e o somatório das suas possíveis vendas##");
        for (Anunciante anunciante : array) {
            if (anunciante != null) {
                if (anunciante.valorTotalVendas() > 0) {
                    System.out.println(anunciante.toString6());
                }
            }
        }
        //7
        System.out.println("##Visualizar, para cada Anunciante, o seu alugável (se existir) que pode gerar maior lucro à Olxyz (quem, o quê e quanto)##");
        for (Anunciante anunciante : array) {
            if (anunciante != null) {
                if (anunciante.getQuantidadeProdutosAlugaveis() > 0) {
                    System.out.println(anunciante.toString7());
                } else {
                    System.out.format("O anunciante %s não tem nenhum produto para alugar.", anunciante.getNome());
                }
            }
        }

    }
}
