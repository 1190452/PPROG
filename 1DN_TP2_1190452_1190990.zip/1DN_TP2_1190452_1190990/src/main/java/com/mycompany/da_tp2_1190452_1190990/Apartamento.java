/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.da_tp2_1190452_1190990;

/** 
 * Esta classe permite criar um apartamento de forma a que o anunciante o possa alugar.
 * 
 * @author Ricardo Pereira
 */
public class Apartamento implements Alugaveis{
    
    /**
     * A designação do apartamento.
     */
    private String designacao;

    /**
     * O endereço do apartamento.
     */
    private Endereco endereco;

    /**
     * A área do apartamento.
     */
    private double area;

    /**
     * O valor de aluguer do apartamento.
     */
    private double valorAluguer;

    /**
     * A designação por omissão.
     */
    private static final String DESIGNACAO_POR_OMISSAO = "sem designacao";

    /**
     * O valor de aluguer por omissão.
     */ 
    private static final double VALORALUGUER_OMISSAO = 0;

    /**
     * A área por omissão.
     */
    private static final double AREA_POR_OMISSAO=100;

    /**
     * A taxa fixa relativa ao aluguer.
     */
    private static double taxaFixaAluguer = 5;
    
    /**
     * Constrói uma instância do Apartamento recebendo a designação, o endereço, a area e o valor de aluguer.
     *
     * @param designacao a designação do apartamento
     * @param endereco o endereço do apartamento
     * @param area a area do apartamento
     * @param valorAluguer o valor de aluguer do apartamento
     */
    public Apartamento(String designacao,Endereco endereco, double area, double valorAluguer){
        this.designacao = designacao;
        this.endereco=new Endereco(endereco);
        this.area = area;
        this.valorAluguer = valorAluguer;
    }
    
    /**
     * Constrói uma instância do Apartamento recebendo recebendo a designação, o endereço, a area e o valor de aluguer por omissão
     */
    public Apartamento(){
        designacao = DESIGNACAO_POR_OMISSAO;
        endereco=new Endereco();
        area = AREA_POR_OMISSAO;
        valorAluguer = VALORALUGUER_OMISSAO;
    }

    /**
     * @return the area
     */
    public double getArea() {
        return area;
    }

    /**
     * @param area the area to set
     */
    public void setArea(double area) {
        this.area = area;
    }

    /**
     * @return the designacao
     */
    public String getDesignacao() {
        return designacao;
    }

    /**
     * @param designacao the designacao to set
     */
    public void setDesignacao(String designacao) {
        this.designacao = designacao;
    }

    @Override
    public double CalcularValorAluguer() {
       return getValorAluguer() * (1 + (getTaxaFixaAluguer()/100));
    }

    /**
     * @return the valorAluguer
     */
    public double getValorAluguer() {
        return valorAluguer;
    }

    /**
     * @param valorAluguer the valorAluguer to set
     */
    public void setValorAluguer(double valorAluguer) {
        this.valorAluguer = valorAluguer;
    }

    /**
     * @return the taxaFixaAluguer
     */
    public static double getTaxaFixaAluguer() {
        return taxaFixaAluguer;
    }

    /**
     * @param aTaxaFixaAluguer the taxaFixaAluguer to set
     */
    public static void setTaxaFixaAluguer(double aTaxaFixaAluguer) {
        taxaFixaAluguer = aTaxaFixaAluguer;
    }
    
    /**
     * Devolve a descrição textual do apartamento com a sua designação, endereço e area.
     *
     * @return caracteristicas do apartamento
     */
    @Override
    public String toString(){
        return String.format("Apartamento %s com endereço %s e área %s",designacao,endereco.toString(),area);
    }
    
    
    
}
