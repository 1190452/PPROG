
package com.mycompany.da_tp2_1190452_1190990;

/** 
 * Esta interface permite calcular o valor dos produtos vendaveis.
 * 
 * @author Ricardo Pereira
 */
public interface Vendaveis {
    public double CalcularValorVenda();
}
