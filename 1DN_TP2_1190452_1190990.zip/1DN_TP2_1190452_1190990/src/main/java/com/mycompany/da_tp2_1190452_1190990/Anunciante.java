/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.da_tp2_1190452_1190990;

import java.util.ArrayList;
import java.util.List;

/** 
 * Esta classe permite criar anunciantes da plataforma OLXYZ.
 * 
 * @author Ricardo Pereira
 */
public class Anunciante {
    /**
     * O nome do anunciante.
     */
    private String nome;

    /**
     * O endereço do anunciante.
     */
    private Endereco endereco;

    /**
     * A lista de produtos vendáveis.
     */
    private List<Vendaveis> listVendaveis;

    /**
     * A lista de produtos alugáveis.
     */
    private List<Alugaveis> listAlugaveis;
    
    /**
    * O nome por omissão.
    */
    private static String NOME_POR_OMISSAO="sem nome";

    /**
     * Constrói uma instância do Anunciante recebendo o nome e o endereço.
     *
     * @param nome o nome do anunciante
     * @param endereco o endereço do anunciante
     */
    public Anunciante(String nome, Endereco endereco){
        this.nome = nome;
        this.endereco = new Endereco(endereco);
        listVendaveis = new ArrayList();
        listAlugaveis = new ArrayList();
    }
    
    /**
     * Constrói uma instância do Anunciante recebendo o nome e o endereço, a lista de vendáveis e a lista de alugáveis
     * @param nome
     * @param endereco
     * @param listVendaveis
     * @param listAlugaveis
     */
    public Anunciante(String nome, Endereco endereco, List<Vendaveis> listVendaveis, List<Alugaveis> listAlugaveis){
        this.nome = nome;
        this.endereco = new Endereco(endereco);
        this.listVendaveis = listVendaveis;
        this.listAlugaveis = listAlugaveis;
    }

    /**
     * Constrói uma instância do Anunciante recebendo o nome e o endereço por omissão
     */
    public Anunciante(){
        nome=NOME_POR_OMISSAO;
        endereco = new Endereco();
    }

    /**
     * Constrói uma cópia da instancia Anunciante criada
     */
    public Anunciante(Anunciante outroAnunciante) {
        nome = outroAnunciante.nome;
        endereco = new Endereco(outroAnunciante.endereco);
 
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the endereco
     */
    public Endereco getEndereco() {
        return new Endereco(endereco);
    }

    /**
     * @param endereco the endereco to set
     */
    public void setEndereco(Endereco endereco) {
        this.endereco.setNomeRua(endereco.getNomeRua());
        this.endereco.setCodigoPostal(endereco.getCodigoPostal());
        this.endereco.setLocalidade(endereco.getLocalidade());
    }

    /**
     * @return the listVendaveis
     */
    public List<Vendaveis> getListVendaveis() {
        return listVendaveis;
    }

    /**
     * @param listVendaveis the listVendaveis to set
     */
    public void setListVendaveis(List<Vendaveis> listVendaveis) {
        this.listVendaveis = listVendaveis;
    }

    /**
     * @return the listAlugaveis
     */
    public List<Alugaveis> getListAlugaveis() {
        return listAlugaveis;
    }

    /**
     * @param listAlugaveis the listAlugaveis to set
     */
    public void setListAlugaveis(ArrayList<Alugaveis> listAlugaveis) {
        this.listAlugaveis = listAlugaveis;
    }

    /**
     * Devolve o tamanho da lista de alugáveis.
     *
     * @return the listAlugaveis.size()
     */
    public int getQuantidadeProdutosAlugaveis(){
        return listAlugaveis.size();
    }
    
    /**
     * Devolve false se o tamanho da lista for igual ou superior a 3.  
     * Se o tamanho for menor que 3, devolve true.
     * 
     * @return false se o tamanho for igual ou superior a 3 caso contrario devolve true
     */
    public boolean addListaAlugaveis(Alugaveis alugavel){
        if (listAlugaveis.contains(alugavel) || listAlugaveis.size() >= 3 ){
            return false;
        }else{
            listAlugaveis.add(alugavel);
            return true;
        }
    }

    /**
     * Devolve false se o tamanho da lista for igual ou superior a 2.Se o tamanho for menor que 2, devolve true.  
     *
     * @param vendaveis 
     * @return false se o tamanho for igual ou superior a 2 caso contrario devolve true
     */
     public boolean addListaVendaveis(Vendaveis vendaveis){
        if (listVendaveis.contains(vendaveis) || listVendaveis.size() >= 2 ){
            return false;
        }else{
            listVendaveis.add(vendaveis);
            return true;
        }
    }  
    
    /**
     * Devolve o alugável mais caro que se encontra na lista
     * 
     * @return alugável mais caro da lista
     */
    public Alugaveis getAlugavelMaisCaro(){
        Alugaveis alugavelMaisCaro = listAlugaveis.get(0);
        double alugavelCaro = listAlugaveis.get(0).CalcularValorAluguer();
        for(int i=1; i<listAlugaveis.size(); i++){
            if(alugavelCaro < listAlugaveis.get(i).CalcularValorAluguer()){
               alugavelMaisCaro = listAlugaveis.get(i);
               alugavelCaro = listAlugaveis.get(i).CalcularValorAluguer();
            }
        }
       return alugavelMaisCaro;
    }
    
    /**
     * Devolve o valor total de vendas que o anunciante pode efetuar com todos os seu produtos
     * 
     * @return valor total das vendas de produtos do anunciante
     */
    public double valorTotalVendas(){
        double total = 0;
        for(int i=0; i<listVendaveis.size();i++){
            total = total + listVendaveis.get(i).CalcularValorVenda();
        }
        return total;
    }
    
    /**
     * Devolve a descrição textual do anunciante como é pedido na alinea 6) com o seu nome, endereço e somatorio das suas possiveis vendas.
     *
     * @return caracteristicas do anunciante pedidas na alinea 6)
     */
    public String toString6(){
        return String.format("Nome: %s\nEndereço: %s\nSomatório das suas possíveis vendas: %.2f\n",nome,endereco.toString(),valorTotalVendas());
        
    }
    
    /**
     * Devolve a descrição textual do anunciante como é pedido na alinea 7) com o seu nome, produto alugável mais caro e valor do respetivo alugavel.
     *
     * @return caracteristicas do anunciante pedidas na alinea 6)
     */
    public String toString7(){
        return String.format("Nome: %s\nProduto: %s\nValor: %.2f\n", nome,getAlugavelMaisCaro(),getAlugavelMaisCaro().CalcularValorAluguer());
    }
}
