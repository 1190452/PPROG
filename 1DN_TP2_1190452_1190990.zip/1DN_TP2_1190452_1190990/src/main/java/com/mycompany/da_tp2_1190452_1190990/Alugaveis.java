
package com.mycompany.da_tp2_1190452_1190990;

/** 
 * Esta interface permite calcular o valor dos produtos alugaveis.
 * 
 * @author Ricardo Pereira
 */
public interface Alugaveis {
    public double CalcularValorAluguer();
    
}
