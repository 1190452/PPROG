package Model;

import Utils.Data;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Ricardo Pereira
 */
public class Seriacao1Test {

    /**
     * Test of maiorMedia method, of class Seriacao1.
     */
    @Test
    public void testMaiorMedia() {
        System.out.println("maiorMedia");
        List<Candidatura> candidaturas = new ArrayList();
        ListaCandidaturas cand = new ListaCandidaturas();
        ListaReconhecimentoCompetencias rc1 = new ListaReconhecimentoCompetencias();
        ListaReconhecimentoCompetencias rc2 = new ListaReconhecimentoCompetencias();
        ListaReconhecimentoCompetencias rc3 = new ListaReconhecimentoCompetencias();
        ListaCompetencias lct = new ListaCompetencias();
        rc1.addReconhecimentoCompetencias(new ReconhecimentoCompetencia(new Data(0, 0, 0), new CompetenciaTecnica(null, null, null, new GrauProficiencia(3, null), true), new GrauProficiencia(4, null)));
        rc2.addReconhecimentoCompetencias(new ReconhecimentoCompetencia(new Data(0, 0, 0), new CompetenciaTecnica(null, null, null, new GrauProficiencia(3, null), true), new GrauProficiencia(5, null)));
        rc3.addReconhecimentoCompetencias(new ReconhecimentoCompetencia(new Data(0, 0, 0), new CompetenciaTecnica(null, null, null, new GrauProficiencia(3, null), true), new GrauProficiencia(5, null)));

        Candidatura c1 = new Candidatura(new Data(2004, 02, 20), 300, 0, null, null, new Freelancer(null, null, new EnderecoPostal("x", "y", "z"), null, null, rc1), "100");
        candidaturas.add(c1);
        Candidatura c2 = new Candidatura(new Data(2004, 03, 10), 200, 0, null, null, new Freelancer(null, null, new EnderecoPostal("x", "y", "z"), null, null, rc2), "100");
        candidaturas.add(c2);
        Candidatura c3 = new Candidatura(new Data(2004, 03, 11), 200, 0, null, null, new Freelancer(null, null, new EnderecoPostal("x", "y", "z"), null, null, rc3), "100");
        candidaturas.add(c3);

        lct.adicionarCompetencia(new CompetenciaTecnica("100", null, null, new GrauProficiencia(2, null), true));

        Anuncio anu = new Anuncio(new Colaborador(null, null, null, null), new Tarefa(null, null, null, null, 0, 0, lct), new Data(0, 0, 0), new Data(0, 0, 0), new Data(0, 0, 0), new Data(0, 0, 0), new Data(0, 0, 0), new Data(0, 0, 0), new TipoRegimento(null, null), null, cand, true);

        List<Candidatura> candidaturaSeriada = new ArrayList<>();
        candidaturaSeriada.add(c2);
        candidaturaSeriada.add(c3);
        candidaturaSeriada.add(c1);

        Seriacao2 instance = new Seriacao2();
        instance.maiorMedia(candidaturas, anu);
        assertEquals(candidaturas, candidaturaSeriada);
    }

    /**
     * Test of precoMaisBaixo method, of class Seriacao1.
     */
    @Test
    public void testPrecoMaisBaixo() {
        System.out.println("precoMaisBaixo");
        ListaReconhecimentoCompetencias rc1 = new ListaReconhecimentoCompetencias();
        ListaReconhecimentoCompetencias rc2 = new ListaReconhecimentoCompetencias();
        rc1.addReconhecimentoCompetencias(new ReconhecimentoCompetencia(new Data(0, 0, 0), new CompetenciaTecnica(null, null, null, new GrauProficiencia(4, null), true), new GrauProficiencia(5, null)));
        rc2.addReconhecimentoCompetencias(new ReconhecimentoCompetencia(new Data(0, 0, 0), new CompetenciaTecnica(null, null, null, new GrauProficiencia(4, null), true), new GrauProficiencia(5, null)));
        Candidatura c1 = new Candidatura(new Data(2004, 02, 20), 300, 0, null, null, new Freelancer(null, null, new EnderecoPostal("x", "y", "z"), null, null, rc1), "100");
        Candidatura c2 = new Candidatura(new Data(2004, 03, 10), 200, 0, null, null, new Freelancer(null, null, new EnderecoPostal("x", "y", "z"), null, null, rc2), "100");
        Seriacao2 instance = new Seriacao2();
        Candidatura expResult = c2;
        Candidatura result = instance.precoMaisBaixo(c1, c2);
        assertEquals(expResult, result);
    }

    /**
     * Test of dataMaisCedo method, of class Seriacao1.
     */
    @Test
    public void testDataMaisCedo() {
        System.out.println("dataMaisCedo");
        ListaReconhecimentoCompetencias rc2 = new ListaReconhecimentoCompetencias();
        ListaReconhecimentoCompetencias rc3 = new ListaReconhecimentoCompetencias();
        rc2.addReconhecimentoCompetencias(new ReconhecimentoCompetencia(new Data(0, 0, 0), new CompetenciaTecnica(null, null, null, new GrauProficiencia(4, null), true), new GrauProficiencia(5, null)));
        rc3.addReconhecimentoCompetencias(new ReconhecimentoCompetencia(new Data(0, 0, 0), new CompetenciaTecnica(null, null, null, new GrauProficiencia(4, null), true), new GrauProficiencia(5, null)));
        Candidatura c1 = new Candidatura(new Data(2004, 03, 10), 200, 0, null, null, new Freelancer(null, null, new EnderecoPostal("x", "y", "z"), null, null, rc2), "100");
        Candidatura c2 = new Candidatura(new Data(2004, 03, 11), 200, 0, null, null, new Freelancer(null, null, new EnderecoPostal("x", "y", "z"), null, null, rc3), "100");
        Seriacao2 instance = new Seriacao2();
        Candidatura expResult = c1;
        Candidatura result = instance.dataMaisCedo(c1, c2);
        assertEquals(expResult, result);
    }

}
