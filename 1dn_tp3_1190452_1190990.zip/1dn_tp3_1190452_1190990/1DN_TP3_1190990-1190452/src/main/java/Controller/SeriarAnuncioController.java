package Controller;

import java.util.List;
import Model.Anuncio;
import Model.Candidatura;
import Model.Colaborador;
import Model.ListaCandidaturas;
import Model.ListaColaboradores;
import Model.ListaCompetencias;
import Model.ListaFreelancers;
import Model.ListaReconhecimentoCompetencias;
import Model.ListaTarefas;
import Model.Organizacao;
import Model.Plataforma;
import Model.ProcessoSeriacao;
import Model.RegistoAnuncios;
import Model.RegistoOrganizacoes;
import Model.Seriacao1;
import Model.Seriacao2;

/**
 *
 * @author Bruno Pereira
 */
public class SeriarAnuncioController {

    /**
     * Objeto referente à classe controller.
     */
    private Plataforma seriar_plataforma;
    /**
     * Objeto referente à classe RegistoOrganizacoes.
     */
    private RegistoOrganizacoes rorg;
    /**
     * Objeto referente à classe Organizacao.
     */
    private Organizacao organizacao;
    /**
     * Objeto referente à classe Colaborador.
     */
    private Colaborador colaborador;
    /**
     * objeto do tipo List<Candidatura>.
     */
    private List<Candidatura> listaCandidaturas;
    /**
     * Objeto referente à classe Seriacao1.
     */
    private Seriacao1 s1;
    /**
     * Objeto referente à classe Seriacao2.
     */
    private Seriacao2 s2;
    /**
     * Objeto referente à classe RegistoAnuncios.
     */
    private RegistoAnuncios ra;
    /**
     * Objeto referente à classe Anuncio.
     */
    private Anuncio anu;
    /**
     * Objeto referente à classe ProcessoSeriacao.
     */
    private ProcessoSeriacao ps;
    /**
     * Objeto referente à classe ListaCandidaturas.
     */
    private ListaCandidaturas listaCand;
    /**
     * Objeto referente à classe ListaTarefas.
     */
    private ListaTarefas ltarefas;
    /**
     * Objeto referente à classe ListaCompetencias.
     */
    private ListaCompetencias lct;
    /**
     * Objeto referente à classe ListaFreelancers.
     */
    private ListaFreelancers lf;
    /**
     * Objeto referente à classe ListaColaboradores.
     */
    private ListaColaboradores lc;
    /**
     * Objeto referente à classe ListaReconhecimentoCompetencias.
     */
    private ListaReconhecimentoCompetencias lrc;

    /*
    *Constrói uma instância do tipo SeriarAnuncioController
     */
    public SeriarAnuncioController(String designacao) {

        this.ltarefas = new ListaTarefas();
        this.lct = new ListaCompetencias();
        this.lf = new ListaFreelancers();
        this.lrc = new ListaReconhecimentoCompetencias();
        this.listaCand = new ListaCandidaturas();
        this.ra = new RegistoAnuncios();
        this.lc = new ListaColaboradores();
        this.rorg = new RegistoOrganizacoes();
        this.seriar_plataforma = new Plataforma(designacao);
        s1 = new Seriacao1();
        s2 = new Seriacao2();

    }

    /*
    *Constrói uma instância do tipo SeriarAnuncioController com a designação.
     */
    public SeriarAnuncioController(String designacao,
            ListaTarefas ltarefas,
            ListaFreelancers lf,
            ListaCandidaturas listCand,
            RegistoAnuncios ra,
            ListaColaboradores lc,
            RegistoOrganizacoes rorg) {

        this.ltarefas = ltarefas;
        this.lf = lf;
        this.listaCand = listCand;
        this.ra = ra;
        this.lc = lc;
        this.rorg = rorg;
        this.seriar_plataforma = new Plataforma(designacao, rorg, ra);
        s1 = new Seriacao1();
        s2 = new Seriacao2();
    }

    /*
    * Método que obtém a lista de anuncios por seriar.
     */
    public List<Anuncio> getAnunciosPorSeriarNaoAutomatico() {
        String email = "organizacao1@isep.com";
        String email2 = "chicodatina@isep.com";
        RegistoOrganizacoes rorgs = seriar_plataforma.getRegistoOrganizacoes();
        this.organizacao = rorgs.getOrganizacaoByEmailUtilizador(email);
        if (organizacao != null) {
            ListaColaboradores listColabs = organizacao.getListaColaboradores();
            colaborador = listColabs.getColaboradorByEmail(email2);

        }

        ra = seriar_plataforma.getRegistoAnuncios();
        if (ra != null) {
            return ra.getAnunciosPorSeriarNaoAutomaticos(colaborador);

        } else {
            return null;
        }

    }

    /*
    * Método que obtém a lista de candidaturas do anuncio por seriar.
     */
    public List<Candidatura> getCandidaturas(String anuncioID) {
        anu = ra.getAnuncioPublicadoPor(colaborador, anuncioID);
        if (anu == null || colaborador == null) {

            return null;
        } else {
            listaCand = anu.getListaCandidaturas();
            listaCandidaturas = listaCand.getCandidaturas();
            ps = anu.novoProcessoSeriacao(colaborador);
            return listaCandidaturas;
        }
    }

    /*
    * Método que seria a lista de candidaturas pelo processo de seriação que o utilizador escolheu.
     */
    public void seriarCandidaturas(List<Candidatura> candidaturas, int tipoSeriacao) {
        if (tipoSeriacao == 1 && s1!=null) {
            s1.seriarlista(candidaturas, anu);

        } else if (tipoSeriacao == 2 && s2 != null) {
            s2.seriarlista(candidaturas, anu);
        }
    }

    /*
    * Método que após a seriação da lista de candidaturas altera o estado de seriação do anúncio.
     */
    public void setPorSeriar(String anuncioID) {
        if (ra == null || colaborador == null) {
            return;
        }

        List<Anuncio> la = ra.getAnunciosPorSeriarNaoAutomaticos(colaborador);
        if (la != null) {
            int size = la.size();

            if (size > 0) {
                for (int i = 0; i < size; i++) {
                    if (la.get(i).getAnuncioID().equalsIgnoreCase(anuncioID)) {
                        la.get(i).setPorSeriar(false);
                    }

                }
            }
        }

    }

}
