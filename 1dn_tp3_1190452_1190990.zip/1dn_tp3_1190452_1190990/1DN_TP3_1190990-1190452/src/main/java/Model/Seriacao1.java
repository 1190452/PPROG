package Model;

import java.util.Collections;
import java.util.List;

/**
 * Esta classe contem os algoritmos de ordenação consoante o 1º processo de
 * seriação
 *
 * @author Bruno Pereira
 */
public class Seriacao1 implements TipoSeriacao {

    /**
     * Método que efetua a comparação de duas candidaturas através do critério
     * maior média.
     *
     * @param candidaturas
     * @param anu
     */
    @Override
    public void maiorMedia(List<Candidatura> candidaturas, Anuncio anu) {
        int size = candidaturas.size() - 1;
        int size2 = candidaturas.size();
        for (int i = 0; i < size; i++) {
            for (int p = i+1; p < size2; p++) {
                double total1 = candidaturas.get(i).getFreelancer().calcularMedia(anu, candidaturas.get(i));
                double total2 = candidaturas.get(p).getFreelancer().calcularMedia(anu, candidaturas.get(p));
                if (total1 < total2) {
                    Collections.swap(candidaturas, i, p);
                } else if (total1 == total2) {
                    Candidatura cb = precoMaisBaixo(candidaturas.get(i), candidaturas.get(p));
                    if (candidaturas.get(p) == cb) {
                        Collections.swap(candidaturas, i, p);
                    }
                }
            }
        }
    }

    /**
     * Método que efetua a comparação de duas candidaturas através do critério
     * de menor custo para efetuar a tarefa.
     *
     * @param c1
     * @param c2
     * @return o objeto de acordo com o preço mais baixo para efetuar a tarefa.
     */
    @Override
    public Candidatura precoMaisBaixo(Candidatura c1, Candidatura c2) {
        if (c1.getValorPretendido() > c2.getValorPretendido()) {
            return c2;
        } else if (c1.getValorPretendido() < c2.getValorPretendido()) {
            return c1;
        } else {
            return dataMaisCedo(c1, c2);
        }
    }

    /**
     * Método que efetua a comparação de duas candidaturas através do critério
     * de menor tempo para efetuar a tarefa.
     *
     * @param c1
     * @param c2
     * @return o objeto de acordo com o menor tempo para efetuar a tarefa.
     */
    @Override
    public Candidatura dataMaisCedo(Candidatura c1, Candidatura c2) {
        if (c1.getDataCandidatura().isMaior(c2.getDataCandidatura())) {
            return c2;
        } else {
            return c1;
        }

    }

    /**
     * Método que inicia a serialização da lista de candidaturas.
     *
     * @param candidaturas
     * @param anu
     */
    @Override
    public void seriarlista(List<Candidatura> candidaturas, Anuncio anu) {
        maiorMedia(candidaturas, anu);

    }

}
