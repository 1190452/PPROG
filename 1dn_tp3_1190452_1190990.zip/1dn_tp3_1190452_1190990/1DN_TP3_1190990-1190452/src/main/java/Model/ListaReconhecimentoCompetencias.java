package Model;

import java.util.ArrayList;
import java.util.List;

/**
 * Esta classe permite criar uma Lista de Reconhecimento das Competencias.
 * 
 * @author Ricardo Pereira
 */
public class ListaReconhecimentoCompetencias {
    /**
     * A Lista dos Reconhecimento das Competencias.
     */
    private List<ReconhecimentoCompetencia> listRC;
    
    /**
     * Constrói uma instância do tipo ListaReconhecimentoCompetencias com o arraylist dos reconhecimentos das competencias tecnicas.
     * 
     */
    public ListaReconhecimentoCompetencias (){
        listRC=new ArrayList<>();
    }
    /**
     * Adiciona um Reconhecimento à lista de Reconhecimentos das competencias.
     * @param r
     */
    public void addReconhecimentoCompetencias(ReconhecimentoCompetencia r){
        getListRC().add(r);
    }

    /**
     * Devolve a Lista de Reconhecimento das Competencias.
     * @return the listRC
     */
    public List<ReconhecimentoCompetencia> getListRC() {
        return listRC;
    }
    
}
