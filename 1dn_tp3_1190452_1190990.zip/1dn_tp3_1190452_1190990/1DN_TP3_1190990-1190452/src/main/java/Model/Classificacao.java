package Model;

/**
 * Esta classe permite criar um Classificacao.
 * 
 * @author Ricardo Pereira
 */
public class Classificacao {
    
    /**
     * Lugar da classificação.
     */
    private int lugar;
    
    /**
     * Constrói uma instância de Classificação que recebe o lugar.
     * @param lugar 
     */
    public Classificacao(int lugar){
        this.lugar = lugar;
    }

    /**
     * Devolve o lugar da classificação.
     * @return the lugar
     */
    public int getLugar() {
        return lugar;
    }

    /**
     * Modifica o lugar da classificação.
     * @param lugar the lugar to set
     */
    public void setLugar(int lugar) {
        this.lugar = lugar;
    }
    
    /**
     * Devolve a descrição textual da classificação com o lugar.
     */
    @Override
    public String toString(){
        return String.format("Lugar: %s", lugar);
    }
}

