package Model;

import java.util.ArrayList;
import java.util.List;

/**
 * Esta classe permite criar uma Lista dos Freelancers.
 *
 * @author Ricardo Pereira
 */
public class ListaFreelancers {
    /**
     * A Lista dos Freelancers.
     */
    private List<Freelancer> listFreelancer;
    
    /**
     * Constrói uma instância do tipo ListaFreelancers com o arraylist dos freelancers.
     * 
     */
    public ListaFreelancers (){
        listFreelancer = new ArrayList<Freelancer>();
    }
    
    /**
     * Devolve a Lista de Freelancers.
     * @return listFreelancer
     */
    public List<Freelancer> getListaFreelancers(){
        return listFreelancer;
    } 
    
    /**
     * Adiciona um Freelancer à lista de Freelancers.
     */
    public void addFreelancer(Freelancer f){
        listFreelancer.add(f);
    }
    
    /**
     * Permite imprimir os dados da lista dos colaboradores.
     */
    public void imprimirDados(){
        for( Freelancer a : listFreelancer){
            if(a != null){
                System.out.println(a.toString());
                System.out.println("");
            }   
        }
    }
    
}
