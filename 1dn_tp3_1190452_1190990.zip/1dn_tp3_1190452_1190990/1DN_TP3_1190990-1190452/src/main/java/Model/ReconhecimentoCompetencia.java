package Model;

import Utils.Data;

/**
 * Esta classe permite criar um Reconhecimento de Competencia
 *
 * @author Bruno Pereira
 */
public class ReconhecimentoCompetencia {

    /**
     * Data do reconhecimento de competência.
     */
    private Data data;
    /**
     * competência técnica do reconhecimento de competência.
     */
    private CompetenciaTecnica compT;
    /**
     * grau de proficiência do reconhecimento de competência.
     */
    private GrauProficiencia gp;

    /**
     * construtor completo com todos os atributos da classe ReconhecimentoCT.
     *
     * @param data
     * @param compT
     * @param gp
     */
    public ReconhecimentoCompetencia(Data data, CompetenciaTecnica compT, GrauProficiencia gp) {
        this.data = data;
        this.compT = compT;
        this.gp = gp;
    }

    /*
      @return the data
     */
    public Data getData() {
        return data;
    }

    /*
      @param data the data to set
     */
    public void setData(Data data) {
        this.data = data;
    }

    /*
      @return the compT
     */
    public CompetenciaTecnica getCompT() {
        return compT;
    }

    /*
     @param compT the compT to set
     */
    public void setCompT(CompetenciaTecnica compT) {
        this.compT = compT;
    }

    /*
      @return the gp
     */
    public GrauProficiencia getGp() {
        return gp;
    }

    /**
     * @param gp the gp to set
     */
    public void setGp(GrauProficiencia gp) {
        this.gp = gp;
    }

    /**
     * Devolve a descrição textual do reconhecimento de competência com a data,
     * a competência técnica e o grau de proficiência.
     */
    @Override
    public String toString() {
        return String.format("Data: %s \nCompetência Técnica: %s \nGrau de Proficiência: %s", data, compT, gp);
    }
}
