package Model;

/**
 * Esta classe permite criar uma Plataforma
 *
 * @author Bruno Pereira
 */
public class Plataforma {

    /**
     * designação da plataforma.
     */
    private String designacao;
    /**
     * RegistoOrganizações que está dentro da plataforma.
     */
    private RegistoOrganizacoes rorgs;
    /**
     * RegistoAnuncios que está dentro da plataforma.
     */
    private RegistoAnuncios ra;

    /**
     * Constrói uma instância do tipo Plataforma com a designação e inicializa a
     * classe registo de organizações.
     *
     * @param designacao
     */
    public Plataforma(String designacao) {
        this.designacao = designacao;
        this.rorgs = new RegistoOrganizacoes();
    }

    /**
     * Constrói uma instância do tipo Plataforma com a designação e o
     * RegistoOrganizações.
     *
     * @param designacao
     * @param rorgs
     */
    public Plataforma(String designacao, RegistoOrganizacoes rorgs) {
        this.designacao = designacao;
        this.rorgs = rorgs;
    }

    /**
     * Constrói uma instância do tipo Plataforma com a designação, o
     * RegistoOrganizações e o RegistoAnuncios.
     *
     * @param designacao
     * @param rorgs
     * @param ra
     */
    public Plataforma(String designacao, RegistoOrganizacoes rorgs, RegistoAnuncios ra) {
        this.designacao = designacao;
        this.rorgs = rorgs;
        this.ra = ra;

    }

    /**
     * @return the rorgs.
     */
    public RegistoOrganizacoes getRegistoOrganizacoes() {
        return rorgs;
    }

    /**
     * @return the ra.
     */
    public RegistoAnuncios getRegistoAnuncios() {
        return ra;
    }

    /**
     * @return the designacao
     */
    public String getDesignacao() {
        return designacao;
    }

    /**
     * @param designacao the designacao to set
     */
    public void setDesignacao(String designacao) {
        this.designacao = designacao;
    }

    /**
     * Devolve a descrição textual da plataforma com a designação.
     */
    @Override
    public String toString() {
        return String.format("Designacao: %s", designacao);
    }

}
