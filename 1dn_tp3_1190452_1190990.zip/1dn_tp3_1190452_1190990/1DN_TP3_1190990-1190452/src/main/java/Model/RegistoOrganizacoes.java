package Model;

import java.util.ArrayList;
import java.util.List;

/**
 * Esta classe permite criar um Registo de Organizações
 *
 * @author Bruno Pereira
 */
public class RegistoOrganizacoes {

    /**
     * Lista de organizações.
     */
    private List<Organizacao> organizacoes;

    /**
     * Constrói uma instância do tipo Registo de organizações com a lista de
     * organizações.
     */
    public RegistoOrganizacoes() {
        organizacoes = new ArrayList<>();
    }

    /**
     * Obtenção da organização através do email.
     *
     * @param email
     * @return a organização
     */
    public Organizacao getOrganizacaoByEmailUtilizador(String email) {
        for (int i = 0; i < organizacoes.size(); i++) {
            if (organizacoes.get(i).getEmail().equalsIgnoreCase(email)) {
                return organizacoes.get(i);
            }
        }
        return null;
    }

    /**
     * Adiciona uma organização à lista de organizações.
     *
     * @param organizacao
     */
    public void addOrganizacao(Organizacao organizacao) {
        organizacoes.add(organizacao);
    }
}
