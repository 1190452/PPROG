package Model;

import Utils.Data;

/**
 * Esta classe permite criar um Anúncio para cada colaborador
 * 
 * @author Bruno Pereira
 */
public class Anuncio {

    /**
     * O Colaborador que possui o anúncio.
     */
    private Colaborador colab;
    /**
     * A Tarefa que o anúncio possui.
     */
    private Tarefa tar;
    /**
     * Data de inicio da publicação do anúncio.
     */
    private Data dtInicioPublicacao;
    /**
     * Data do fim da publicação do anúncio.
     */
    private Data dtFimPublicacao;
    /**
     * Data de inicio da canddidatura ao anúncio.
     */
    private Data dtInicioCandidatura;
    /**
     * Data do fim da canddidatura ao anúncio.
     */
    private Data dtFimCandidatura;
    /**
     * Data de início da seriação do anúncio.
     */
    private Data dtInicioSeriacao;
    /**
     * Data do fim da seriação do anúncio.
     */
    private Data dtFimSeriacao;
    /**
     * Tipo de Regimento associado ao Anúncio.
     */
    private TipoRegimento tipoReg;
    /**
     * ID que identifica o anúncio.
     */
    private String anuncioID;
    /**
     * Variável booleana que nos indica o estado de seriação do anúncio.
     */
    private boolean porSeriar;
    /**
     * Lista que engloba todas as candidaturas feitas a este anúncio.
     */
    private ListaCandidaturas cand;

    /**
     * Constrói uma instância do Anúncio recebendo o colaborador, a tarefa, as
     * datas de publicação, de candidatura e de seriação, o tipo de regimento, o
     * ID do anúncio, a lista de candidaturas e o seu estado de seriação.
     *
     * @param colab
     * @param tar
     * @param dtInicioPublicacao
     * @param dtFimPublicacao
     * @param dtInicioCandidatura
     * @param dtFimCandidatura
     * @param dtInicioSeriacao
     * @param dtFimSeriacao
     * @param tipoReg
     * @param anuncioID
     * @param cand
     * @param porSeriar
     */
    public Anuncio(Colaborador colab, Tarefa tar, Data dtInicioPublicacao, Data dtFimPublicacao, Data dtInicioCandidatura, Data dtFimCandidatura, Data dtInicioSeriacao, Data dtFimSeriacao, TipoRegimento tipoReg, String anuncioID, ListaCandidaturas cand, boolean porSeriar) {
        this.colab = colab;
        this.tar = tar;
        this.dtInicioPublicacao = dtInicioPublicacao;
        this.dtFimPublicacao = dtFimPublicacao;
        this.dtInicioCandidatura = dtInicioCandidatura;
        this.dtFimCandidatura = dtFimCandidatura;
        this.dtInicioSeriacao = dtInicioSeriacao;
        this.dtFimSeriacao = dtFimSeriacao;
        this.tipoReg = tipoReg;
        this.anuncioID = anuncioID;
        this.porSeriar = porSeriar;
        this.cand = cand;

    }

    /**
     * @return the dtInicioPublicacao
     */
    public Data getDtInicioPublicacao() {
        return dtInicioPublicacao;
    }

    /**
     * @param dtInicioPublicacao the dtInicioPublicacao to set
     */
    public void setDtInicioPublicacao(Data dtInicioPublicacao) {
        this.dtInicioPublicacao = dtInicioPublicacao;
    }

    /**
     * @return the dtFimPublicacao
     */
    public Data getDtFimPublicacao() {
        return dtFimPublicacao;
    }

    /**
     * @param dtFimPublicacao the dtFimPublicacao to set
     */
    public void setDtFimPublicacao(Data dtFimPublicacao) {
        this.dtFimPublicacao = dtFimPublicacao;
    }

    /**
     * @return the dtInicioCandidatura
     */
    public Data getDtInicioCandidatura() {
        return dtInicioCandidatura;
    }

    /**
     * @param dtInicioCandidatura the dtInicioCandidatura to set
     */
    public void setDtInicioCandidatura(Data dtInicioCandidatura) {
        this.dtInicioCandidatura = dtInicioCandidatura;
    }

    /**
     * @return the dtFimCandidatura
     */
    public Data getDtFimCandidatura() {
        return dtFimCandidatura;
    }

    /**
     * @param dtFimCandidatura the dtFimCandidatura to set
     */
    public void setDtFimCandidatura(Data dtFimCandidatura) {
        this.dtFimCandidatura = dtFimCandidatura;
    }

    /**
     * @return the dtInicioSeriacao
     */
    public Data getDtInicioSeriacao() {
        return dtInicioSeriacao;
    }

    /**
     * @param dtInicioSeriacao the dtInicioSeriacao to set
     */
    public void setDtInicioSeriacao(Data dtInicioSeriacao) {
        this.dtInicioSeriacao = dtInicioSeriacao;
    }

    /**
     * @return the dtFimSeriacao
     */
    public Data getDtFimSeriacao() {
        return dtFimSeriacao;
    }

    /**
     * @param dtFimSeriacao the dtFimSeriacao to set
     */
    public void setDtFimSeriacao(Data dtFimSeriacao) {
        this.dtFimSeriacao = dtFimSeriacao;
    }

    /**
     * Devolve a descrição textual do Anúncio com o colaborador, a tarefa, as
     * datas de publicação, de candidatura e de seriação, o tipo de regimento, o
     * ID do anúncio, e o seu estado de seriação.
     */
    @Override
    public String toString() {
        return String.format("AnúncioID: %s \nColaborador: %s \nTarefa: %s \nData de início da publicitação: %s "
                + "\nData de fim da publicitação: %s \nData de início da candidatura: %s "
                + "\nData de fim da candidatura: %s \nData de início da seriação: %s "
                + "\nData de fim da seriação: %s \nTipo de Regimento: %sPor Seriar?: %s", anuncioID, colab, tar,
                dtInicioPublicacao, dtFimPublicacao, dtInicioCandidatura, dtFimCandidatura, dtInicioSeriacao,
                dtFimSeriacao, tipoReg, porSeriar);
    }

    /**
     *
     * @param colab
     * @return um novo processo de seriação com um tipo de regimento associado
     * ao colaborador
     */
    public ProcessoSeriacao novoProcessoSeriacao(Colaborador colab) {
        tipoReg = new TipoRegimento("sioefioej", "ngfis");

        return new ProcessoSeriacao(tipoReg, colab);
    }

    /**
     * @return the colab
     */
    public Colaborador getColab() {
        return colab;
    }

    /**
     * @param colab the colab to set
     */
    public void setColab(Colaborador colab) {
        this.colab = colab;
    }

    /**
     * @return the tar
     */
    public Tarefa getTar() {
        return tar;
    }

    /**
     * @param tar the tar to set
     */
    public void setTar(Tarefa tar) {
        this.tar = tar;
    }

    /**
     * @return the anuncioID
     */
    public String getAnuncioID() {
        return anuncioID;
    }

    /**
     * @param anuncioID the anuncioID to set
     */
    public void setAnuncioID(String anuncioID) {
        this.anuncioID = anuncioID;
    }

    /**
     * @return a lista de candidaturas
     */
    public ListaCandidaturas getListaCandidaturas() {
        return cand;
    }

    /**
     * @return the porSeriar
     */
    public boolean isPorSeriar() {
        return porSeriar;
    }

    /**
     * @param porSeriar the porSeriar to set
     */
    public void setPorSeriar(boolean porSeriar) {
        this.porSeriar = porSeriar;
    }

}
