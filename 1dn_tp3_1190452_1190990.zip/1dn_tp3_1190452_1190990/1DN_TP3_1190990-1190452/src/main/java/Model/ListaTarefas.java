package Model;

import java.util.ArrayList;
import java.util.List;

/**
 * Esta classe permite criar uma Lista das Tarefas.
 *
 * @author Ricardo Pereira
 */
public class ListaTarefas {

    /**
     * Lista de Tarefas.
     */
    private List<Tarefa> listTar;

    /**
     * Inicializa a lista de tarefas.
     */
    public ListaTarefas() {
        listTar = new ArrayList<>();
    }

    /**
     * @return a lista de tarefas.
     */
    public List<Tarefa> getListaTarefas() {
        return listTar;
    }

    /**
     * Adiciona uma tarefa à lista de tarefas.
     *
     * @param tf
     */
    public void addTarefa(Tarefa tf)throws IllegalArgumentException  {
        if (tf == null) {
            throw new IllegalArgumentException("A tarefa não pode ser nula.");
        }else{
        listTar.add(tf);
        }
    }

    /**
     * Método que obtém uma tarefa através da sua refrência.
     *
     * @param referencia
     * @return a tarefa
     */
    public Tarefa getTarefaByReferencia(String referencia) {
        for (int i = 0; i < listTar.size(); i++) {
            if (listTar.get(i).getReferencia().equalsIgnoreCase(referencia)) {
                return listTar.get(i);
            }
        }
        return null;
    }

}
