package Model;

/**
 * Esta classe permite criar uma Tarefa
 *
 * @author Bruno Pereira
 */
public class Tarefa {

    /**
     * referência da Tarefa.
     */
    private String referencia;
    /**
     * designação da Tarefa.
     */
    private String designacao;
    /**
     * descrição informal da Tarefa.
     */
    private String descInformal;
    /**
     * descrição técnica da Tarefa.
     */
    private String descTecnica;
    /**
     * duração de tempo estimada para realizar a Tarefa.
     */
    private int duracaoEst;
    /**
     * custo estimado para realizar a Tarefa.
     */
    private double custoEst;
    /**
     * Lista de competências necessárias associada à tarefa.
     */
    private ListaCompetencias ListaCT;

    /**
     * Constrói uma instância do tipo Tarefa com a referência, a designacao,
     * descrição informal descrição técnica, duração de tempo e custo da tarefa
     * e a lista de competências que a tarefa possui.
     *
     * @param referencia
     * @param designacao
     * @param descInformal
     * @param descTecnica
     * @param duracaoEst
     * @param custoEst
     * @param ListaCT
     */
    public Tarefa(String referencia, String designacao, String descInformal, String descTecnica, int duracaoEst, double custoEst, ListaCompetencias ListaCT) {
        this.referencia = referencia;
        this.designacao = designacao;
        this.descInformal = descInformal;
        this.descTecnica = descTecnica;
        this.duracaoEst = duracaoEst;
        this.custoEst = custoEst;
        this.ListaCT = ListaCT;

    }

    /**
     * @return the referencia
     */
    public String getReferencia() {
        return referencia;
    }

    /**
     * @param referencia the referencia to set
     */
    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    /**
     * @return the designacao
     */
    public String getDesignacao() {
        return designacao;
    }

    /**
     * @param designacao the designacao to set
     */
    public void setDesignacao(String designacao) {
        this.designacao = designacao;
    }

    /**
     * @return the descInformal
     */
    public String getDescInformal() {
        return descInformal;
    }

    /**
     * @param descInformal the descInformal to set
     */
    public void setDescInformal(String descInformal) {
        this.descInformal = descInformal;
    }

    /**
     * @return the descTecnica
     */
    public String getDescTecnica() {
        return descTecnica;
    }

    /**
     * @param descTecnica the descTecnica to set
     */
    public void setDescTecnica(String descTecnica) {
        this.descTecnica = descTecnica;
    }

    /**
     * @return the duracaoEst
     */
    public int getDuracaoEst() {
        return duracaoEst;
    }

    /**
     * @param duracaoEst the duracaoEst to set
     */
    public void setDuracaoEst(int duracaoEst) {
        this.duracaoEst = duracaoEst;
    }

    /**
     * @return the custoEst
     */
    public double getCustoEst() {
        return custoEst;
    }

    /**
     * @param custoEst the custoEst to set
     */
    public void setCustoEst(double custoEst) {
        this.custoEst = custoEst;
    }

    /**
     * Devolve a descrição textual da Tarefa com a referência, a designacao,
     * descrição informal descrição técnica, duração de tempo e custo da tarefa
     * e a lista de competências que a tarefa possui.
     */
    @Override
    public String toString() {
        return String.format("\nReferência: %s \nDesignação: %s \nDescrição Informal: %s \nDescrição Técnica: %s \nDuração Estimada: %s dias \nCusto: %s euros", referencia, designacao, descInformal, descTecnica,
                duracaoEst, custoEst);
    }

    /**
     * @return the ListaCT
     */
    public ListaCompetencias getMetodoListaCT() {
        return ListaCT;
    }

    /**
     * @param ListaCT the ListaCT to set
     */
    public void setMetodoListaCT(ListaCompetencias ListaCT) {
        this.ListaCT = ListaCT;
    }
}
