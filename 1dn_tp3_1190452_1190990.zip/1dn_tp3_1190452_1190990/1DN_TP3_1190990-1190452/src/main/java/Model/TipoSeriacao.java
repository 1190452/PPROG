package Model;

import java.util.List;

/**
 *
 * @author Bruno Pereira
 */
public interface TipoSeriacao {
    public void maiorMedia(List <Candidatura> candidaturas, Anuncio anu);
    public Candidatura precoMaisBaixo(Candidatura c1, Candidatura c2);
    public Candidatura dataMaisCedo(Candidatura c1, Candidatura c2); 
    public void seriarlista(List <Candidatura> candidaturas, Anuncio anu);
}
