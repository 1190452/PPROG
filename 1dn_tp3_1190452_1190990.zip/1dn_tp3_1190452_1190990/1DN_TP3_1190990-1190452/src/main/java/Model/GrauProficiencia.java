package Model;

/**
 * Esta classe permite criar um Grau de Proficiencia
 * 
 * @author Ricardo Pereira
 */
public class GrauProficiencia {
    /**
     * O Valor do Grau de Proficiencia.
     */
    private int valor;
    /**
     * A Designação do Grau de Proficiencia.
     */
    private String designacao;
    
    /**
     * Constrói uma instância do tipo GrauProficiencia com o valor e designacao.
     * 
     * @param valor
     * @param designacao 
     */
    public GrauProficiencia(int valor, String designacao){
        this.valor = valor;
        this.designacao = designacao;
    }

    /**
     * Devolve o valor do grau de proficiência
     * @return the valor
     */
    public int getValor() {
        return valor;
    }

    /**
     * Modifica o valor do grau de proficiência
     * @param valor the valor to set
     */
    public void setValor(int valor) {
        this.valor = valor;
    }

    /**
     * Devolve a designação do grau de proficiência
     * @return the designacao
     */
    public String getDesignacao() {
        return designacao;
    }

    /**
     * Modifica a designação do grau de proficiência
     * @param designacao the designacao to set
     */
    public void setDesignacao(String designacao) {
        this.designacao = designacao;
    }
    
    /**
     * Devolve a descrição textual do Grau Proficiencia com o valor e a designacao.
     */
    @Override
    public String toString(){
        return String.format("Valor: %d \nDesignação: %s",valor, designacao);
    }

    
}
