package Model;

/**
 * Esta classe permite criar um Tipo de Regimento
 *
 * @author Bruno Pereira
 */
public class TipoRegimento {
    /**
     * designação do tipo de regimento.
     */
    private String designacao;
    /**
     * descrição das regras do tipo de regimento.
     */
    private String descricaoRegras;
    /**
     * Constrói uma instância do tipo de regimento com a designação e a descrição das regras.
     * @param designacao
     * @param descricaoRegras
     */
    public TipoRegimento(String designacao, String descricaoRegras){
        this.designacao = designacao;
        this.descricaoRegras = descricaoRegras;
        
    }

    /**
     * @return the designacao
     */
    public String getDesignacao() {
        return designacao;
    }

    /**
     * @param designacao the designacao to set
     */
    public void setDesignacao(String designacao) {
        this.designacao = designacao;
    }

    /**
     * @return the descricaoRegras
     */
    public String getDescricaoRegras() {
        return descricaoRegras;
    }

    /**
     * @param descricaoRegras the descricaoRegras to set
     */
    public void setDescricaoRegras(String descricaoRegras) {
        this.descricaoRegras = descricaoRegras;
    }
    /**
     * Devolve a descrição textual do tipo de regimento com a designação
     * e a descrição das regras.
     */
    @Override
    public String toString(){
        return String.format("\nDesignação:%s%nDescrição Regras:%s%n",designacao,descricaoRegras);
    }
}

