package Model;

import java.util.ArrayList;
import java.util.List;

/**
 * Esta classe permite criar uma Lista de Colaboradores.
 *
 * @author Ricardo Pereira
 */

public class ListaColaboradores {
    /**
     * A Lista das Candidaturas.
     */
    private List<Colaborador> listaColaboradores;
    
    /**
     * Constrói uma instância do tipo ListaColaboradores com o arraylist dos Colaboradores.
     * 
     */
    public ListaColaboradores(){
        listaColaboradores = new ArrayList<Colaborador>();
    }
    
    /**
     * Devolve o colaborador atraves do email.
     * 
     * @return colaborador
     */
    public Colaborador getColaboradorByEmail(String email) {
        if(listaColaboradores != null && listaColaboradores.size()>0){
        for(int i=0; i<listaColaboradores.size();i++){
                if(listaColaboradores.get(i).getEmail().equalsIgnoreCase(email)){
                    return listaColaboradores.get(i);
                }
            }
        }
        return null;  
    }
    
    /**
     * Devolve a lista de colaboradores
     * @return listaColaboradores
     */
    public List<Colaborador> getListaColaboradores(){
        return listaColaboradores;
    }
    
    /**
     * Adiciona uma candidatura à lista dos colaboradores
     */
    public void addColaborador(Colaborador colaborador) {
        if (colaborador == null) {
            throw new IllegalArgumentException("A categoria não pode ser nula.");
        }
        listaColaboradores.add(colaborador);
    }
    
    /**
     * Permite imprimir os dados da lista dos colaboradores.
     */
    public void imprimirDados(){
        for( Colaborador a : listaColaboradores){
            if(a != null){
                System.out.println(a.toString());
                System.out.println("");
            }   
        }
    }
    
}
