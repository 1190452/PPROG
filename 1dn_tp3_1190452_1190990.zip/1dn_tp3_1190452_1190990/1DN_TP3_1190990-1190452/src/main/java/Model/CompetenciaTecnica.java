package Model;

/**
 * Esta classe permite criar Competencias Tecnicas
 *
 * @author Ricardo Pereira
 */
public class CompetenciaTecnica {
    /**
     * O Codigo da Competência Técnica.
     */
    private String codigo;
    /**
     * A Descrição Breve da Competência Técnica.
     */
    private String descBreve;
    /**
     * A Descrição Detalhada da Competência Técnica.
     */
    private String descDetalhada;
    /**
     * O grau de Proficiencia da Competência Técnica.
     */
    private GrauProficiencia gpf;
    /**
     * O Caracter da Competência Técnica.
     */
    private boolean caraterCT;
    /**
     * Constrói uma instância do tipo CompetenciaTecnica com o codigo, descricao breve, descricao detalhada, grau de proficiencia e caracter.
     * 
     * @param codigo
     * @param descBreve
     * @param descDetalhada
     * @param gpf
     * @param caraterCT 
     */
    public CompetenciaTecnica(String codigo,String descBreve, String descDetalhada, GrauProficiencia gpf, boolean caraterCT){
        this.codigo = codigo;
        this.descBreve = descBreve;
        this.descDetalhada = descDetalhada;
        this.gpf = gpf;
        this.caraterCT = caraterCT;
    }
    
    /**
     * Devolve o Codigo da Competencia Tecnica.
     * @return the codigo
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * Modifica o Codigo da Competencia Tecnica.
     * @param codigo the codigo to set
     */
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    /**
     * Devolve a descricao breve da Competencia Tecnica.
     * @return the descBreve
     */
    public String getDescBreve() {
        return descBreve;
    }

    /**
     * Modifica a descricao breve da Competencia Tecnica.
     * @param descBreve the descBreve to set
     */
    public void setDescBreve(String descBreve) {
        this.descBreve = descBreve;
    }

    /**
     * Devolve a descricao detalhada da Competencia Tecnica.
     * @return the descDetalhada
     */
    public String getDescDetalhada() {
        return descDetalhada;
    }

    /**
     * Modifica a descricao detalhada da Competencia Tecnica.
     * @param descDetalhada the descDetalhada to set
     */
    public void setDescDetalhada(String descDetalhada) {
        this.descDetalhada = descDetalhada;
    }
    
    /**
     * Devolve o grau de proficiencia da Competencia Tecnica.
     * @return the gpf 
     */
    public GrauProficiencia getGrauProficiencia(){
        return gpf;
    }
    
    /**
     * Devolve true se for obrigatório ou false se não for obrigatório.
     * @return the caraterCT
     */
    public boolean isCaraterCT() {
        return caraterCT;
    }

    /**
     * Modifica o caracterCT da Competencia Tecnica.
     * @param caraterCT the caraterCT to set
     */
    public void setCaraterCT(boolean caraterCT) {
        this.caraterCT = caraterCT;
    }
    
    /**
     * Devolve a descrição textual da Competencia Tecnica com código, Descrição Breve, Descrição Detalhada, Grau de Proficiência mínimo, CaraterCT.
     */
    @Override
    public String toString(){
        return String.format("Codigo: %s \nDescrição Breve: %s \nDescrição Detalhada %s \nGrau de Proficiência mínimo: %s \nCaraterCT: %s", codigo, descBreve, descDetalhada, gpf,caraterCT);
    }
    
    
}


