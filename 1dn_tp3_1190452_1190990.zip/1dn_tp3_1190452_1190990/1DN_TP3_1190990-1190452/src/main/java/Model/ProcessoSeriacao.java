package Model;

/**
 * Esta classe permite criar um Processo de Seriação
 *
 * @author Bruno Pereira
 */
public class ProcessoSeriacao {

    /**
     * Tipo de regimento do processo de seriação.
     */
    private TipoRegimento tipoReg;
    /**
     * colaborador associado ao processo de seriação.
     */
    private Colaborador colab;

    /**
     * Constrói uma instância do tipo processo de seriação com o tipo de
     * regimento e o colaborador.
     *
     * @param tipoReg
     * @param colab
     */
    ProcessoSeriacao(TipoRegimento tipoReg, Colaborador colab) {
        this.colab = colab;
        this.tipoReg = tipoReg;

    }

    /**
     * @return the tipoReg
     */
    public TipoRegimento getTipoReg() {
        return tipoReg;
    }

    /**
     * @param tipoReg the tipoReg to set
     */
    public void setTipoReg(TipoRegimento tipoReg) {
        this.tipoReg = tipoReg;
    }

    /**
     * @return the colab
     */
    public Colaborador getColab() {
        return colab;
    }

    /**
     * @param colab the colab to set
     */
    public void setColab(Colaborador colab) {
        this.colab = colab;
    }

    /**
     * Devolve a descrição textual do processo de seriação com o tipo de
     * regimento e o colaborador.
     */
    @Override
    public String toString() {
        return String.format("\nTipo de Regimento: %s \nColaborador: %s", tipoReg, colab);
    }

}
