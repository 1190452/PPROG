package Model;

/**
 * Esta classe permite criar um Colaborador.
 * 
 * @author Ricardo Pereira
 */
public class Colaborador {
    
    /**
     * Nome do colaborador.
     */
    private String nome;
    /**
     * Função do Colaborador.
     */
    private String funcao;
    /**
     * Telefone do Colaborador.
     */
    private String telefone;
    /**
     * Email do Colaborador.
     */
    private String email;
    /**
     * Constrói uma instância do tipo Colaborador com o nome, função, telefone e email.
     * @param nome
     * @param funcao
     * @param telefone
     * @param email 
     */
    public Colaborador (String nome, String funcao, String telefone, String email){
        this.nome=nome;
        this.funcao=funcao;
        this.telefone=telefone;
        this.email=email;
    }

    /**
     * Devolve o nome do colaborador.
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * Modifica o nome do colaborador.
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Devolve a funcao do colaborador.
     * @return the funcao
     */
    public String getFuncao() {
        return funcao;
    }

    /**
     * Modifica a funcao do colaborador.
     * @param funcao the funcao to set
     */
    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    /**
     * Devolve o telefone do colaborador.
     * @return the telefone
     */
    public String getTelefone() {
        return telefone;
    }

    /**
     * Modifica o telefone do colaborador.
     * @param telefone the telefone to set
     */
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    /**
     * Devolve o email do colaborador.
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Modifica o email do colaborador.
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }
    
    /**
     * Devolve a descrição textual do COlaborador com o nome, função, telefone e email
     */
    @Override
    public String toString(){
        return String.format("\nNome: %s \nFunção: %s \nTelefone: %s \nEmail: %s", nome, funcao, telefone, email);
    }
    
}

