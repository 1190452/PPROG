package Model;

import Utils.Data;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * Esta classe permite carregar todos os ficheiros de texto.
 *
 * @author Ricardo Pereira
 */
public class CarregarFicheirosTexto {
    
    private RegistoOrganizacoes rOrg;
    private ListaColaboradores colabOrg;
    private RegistoAnuncios listRegan;
    private ListaFreelancers listfree;
    private ListaTarefas listTar;
    private ListaCompetencias lct;
    private ListaCompetencias lctTarefa;
    private ListaReconhecimentoCompetencias lrcFreelancer;
    private ListaCandidaturas lcand;
    private ListaCandidaturas lcandAnuncio;
    private ListaColaboradores listaColaboradores;
    private Colaborador cAnuncio;
    private Tarefa tAnuncio;
    private static final int maxCompetencias = 4;
    
    public RegistoOrganizacoes carregarOrganizacoes() {
        try {
            Scanner sc = new Scanner(new File("listaOrganizacoes.txt"), "utf-8");
            sc.useDelimiter(";|\n");
            rOrg = new RegistoOrganizacoes();
            colabOrg = new ListaColaboradores();
            try {
                while (sc.hasNext()) {
                    String nome = sc.next().trim();
                    String NIF = sc.next().trim();
                    String website = sc.next().trim();
                    String telefone = sc.next().trim();
                    String email = sc.next().trim();
                    String emailColab = sc.next().trim();
                    for (int i = 0; i < listaColaboradores.getListaColaboradores().size(); i++) {
                        if (listaColaboradores.getListaColaboradores().get(i).getEmail().equalsIgnoreCase(emailColab)) {
                            colabOrg.addColaborador(listaColaboradores.getListaColaboradores().get(i));
                        }
                    }
                    
                    rOrg.addOrganizacao(new Organizacao(nome, NIF, website, telefone, email, colabOrg));
                    colabOrg = new ListaColaboradores();
                    
                }
                
            } catch (NoSuchElementException e) {
                
                System.out.println("Erro a ler o ficheiro listaColaboradores. Verifique o ficheiro .txt em causa.");
                
            }
            
            sc.close();
        } catch (FileNotFoundException e) {
            System.out.println("O ficheiro que está a tentar carregar nao existe.");
            
        }
        return rOrg;
    }
    
    public ListaColaboradores carregarListaColaborador() {
        try {
            Scanner sc = new Scanner(new File("listaColaboradores.txt"), "utf-8");
            sc.useDelimiter(";|\n");
            listaColaboradores = new ListaColaboradores();
            try {
                while (sc.hasNext()) {
                    String nome = sc.next().trim();
                    String func = sc.next().trim();
                    String tele = sc.next().trim();
                    String email = sc.next().trim();
                    
                    listaColaboradores.addColaborador(new Colaborador(nome, func, tele, email));
                    
                }
                
            } catch (NoSuchElementException e) {
                
                System.out.println("Erro a ler o ficheiro listaColaboradores. Verifique o ficheiro .txt em causa.");
                
            }
            
            sc.close();
        } catch (FileNotFoundException e) {
            System.out.println("O ficheiro que está a tentar carregar nao existe.");
            
        }
        return listaColaboradores;
        
    }
    
    public RegistoAnuncios carregarListaAnuncios() {
        try {
            Scanner sc = new Scanner(new File("listaAnuncios.txt"), "utf-8");
            lcandAnuncio = new ListaCandidaturas();
            listRegan = new RegistoAnuncios();
            sc.useDelimiter(";|\n");
            try {
                while (sc.hasNext()) {
                    
                    String emailC = sc.next().trim();
                    String refTarefa = sc.next().trim();
                    int ano1 = Integer.parseInt(sc.next().trim());
                    int mes1 = Integer.parseInt(sc.next().trim());
                    int dia1 = Integer.parseInt(sc.next().trim());
                    int ano2 = Integer.parseInt(sc.next().trim());
                    int mes2 = Integer.parseInt(sc.next().trim());
                    int dia2 = Integer.parseInt(sc.next().trim());
                    int ano3 = Integer.parseInt(sc.next().trim());
                    int mes3 = Integer.parseInt(sc.next().trim());
                    int dia3 = Integer.parseInt(sc.next().trim());
                    int ano4 = Integer.parseInt(sc.next().trim());
                    int mes4 = Integer.parseInt(sc.next().trim());
                    int dia4 = Integer.parseInt(sc.next().trim());
                    int ano5 = Integer.parseInt(sc.next().trim());
                    int mes5 = Integer.parseInt(sc.next().trim());
                    int dia5 = Integer.parseInt(sc.next().trim());
                    int ano6 = Integer.parseInt(sc.next().trim());
                    int mes6 = Integer.parseInt(sc.next().trim());
                    int dia6 = Integer.parseInt(sc.next().trim());
                    String desig = sc.next().trim();
                    String descricaoRegras = sc.next().trim();
                    String anuncioID = sc.next().trim();
                    boolean porSeriar = Boolean.parseBoolean(sc.next().trim());
                    String cand1 = sc.next().trim();
                    String cand2 = sc.next().trim();
                    String cand3 = sc.next().trim();
                    String cand4 = sc.next().trim();
                    for (int i = 0; i < listaColaboradores.getListaColaboradores().size(); i++) {
                        if (listaColaboradores.getListaColaboradores().get(i).getEmail().equalsIgnoreCase(emailC)) {
                            cAnuncio = listaColaboradores.getListaColaboradores().get(i);
                        }
                    }
                    
                    for (int p = 0; p < listTar.getListaTarefas().size(); p++) {
                        if (listTar.getListaTarefas().get(p).getReferencia().equalsIgnoreCase(refTarefa)) {
                            tAnuncio = listTar.getListaTarefas().get(p);
                        }
                    }
                    
                    for (int z = 0; z < lcand.getCandidaturas().size(); z++) {
                        if (lcand.getCandidaturas().get(z).getCandID().equals(cand1) || lcand.getCandidaturas().get(z).getCandID().equals(cand2) || lcand.getCandidaturas().get(z).getCandID().equals(cand3) || lcand.getCandidaturas().get(z).getCandID().equals(cand4)) {
                            lcandAnuncio.addCandidatura(lcand.getCandidaturas().get(z));
                        }
                    }
                    
                    listRegan.addRegistoAnuncios(new Anuncio(cAnuncio, tAnuncio, new Data(ano1, mes1, dia1), new Data(ano2, mes2, dia2),
                            new Data(ano3, mes3, dia3), new Data(ano4, mes4, dia4), new Data(ano5, mes5, dia5), new Data(ano6, mes6, dia6),
                            new TipoRegimento(desig, descricaoRegras), anuncioID, lcandAnuncio, porSeriar));
                    lcandAnuncio = new ListaCandidaturas();
                }
            } catch (NoSuchElementException e) {
                System.out.println("Erro a ler o ficheiro listaAnuncios. Verifique o ficheiro .txt em causa.");
            } finally {
                sc.close();
            }
            
        } catch (FileNotFoundException e) {
            System.out.println("O ficheiro que está a tentar carregar nao existe.");
        }
        return listRegan;
    }
    
    public ListaCandidaturas carregarListaCandidaturas() {
        try {
            Scanner sc = new Scanner(new File("listaCandidaturas.txt"), "utf-8");
            lcand = new ListaCandidaturas();
            sc.useDelimiter(";|\n");
            try {
                while (sc.hasNext()) {
                    int ano = Integer.parseInt(sc.next().trim());
                    int mes = Integer.parseInt(sc.next().trim());
                    int dia = Integer.parseInt(sc.next().trim());
                    double valorPretendido = Double.parseDouble(sc.next().trim());
                    int ndias = Integer.parseInt(sc.next().trim());
                    String txtApresentacao = sc.next().trim();
                    String txtMotivacao = sc.next().trim();
                    String emailF = sc.next().trim();
                    String candID = sc.next().trim();
                    for (int i = 0; i < listfree.getListaFreelancers().size(); i++) {
                        if (listfree.getListaFreelancers().get(i).getEmail().equalsIgnoreCase(emailF)) {
                            Freelancer f = listfree.getListaFreelancers().get(i);
                            lcand.addCandidatura(new Candidatura(new Data(ano, mes, dia), valorPretendido, ndias, txtApresentacao, txtMotivacao, f, candID));
                        }
                    }
                }
            } catch (NoSuchElementException e) {
                System.out.println("Erro a ler o ficheiro listaAnuncios. Verifique o ficheiro .txt em causa.");
            } finally {
                sc.close();
            }
            
        } catch (FileNotFoundException e) {
            System.out.println("O ficheiro que está a tentar carregar nao existe.");
        }
        return lcand;
    }
    
    public ListaFreelancers carregarListaFreelancer() {
        try {
            Scanner sc = new Scanner(new File("listaFreelancers.txt"), "utf-8");
            listfree = new ListaFreelancers();
            lrcFreelancer = new ListaReconhecimentoCompetencias();
            sc.useDelimiter(";|\n");
            try {
                while (sc.hasNext()) {
                    String nome = sc.next().trim();
                    String nif = sc.next().trim();
                    String local = sc.next().trim();
                    String codigoP = sc.next().trim();
                    String localidade = sc.next().trim();
                    String tele = sc.next().trim();
                    String email = sc.next().trim();
                    for (int i = 0; i < maxCompetencias; i++) {
                        int ano = Integer.parseInt(sc.next().trim());
                        int mes = Integer.parseInt(sc.next().trim());
                        int dia = Integer.parseInt(sc.next().trim());
                        String codigo = sc.next().trim();
                        int v = Integer.parseInt(sc.next().trim());
                        String des = sc.next().trim();
                        for (int p = 0; p < lct.getCompetencias().size(); p++) {
                            if (lct.getCompetencias().get(p).getCodigo().equals(codigo)) {
                                CompetenciaTecnica c1 = lct.getCompetencias().get(p);
                                
                                lrcFreelancer.addReconhecimentoCompetencias(new ReconhecimentoCompetencia(new Data(ano, mes, dia), c1, new GrauProficiencia(v, des)));
                            }
                        }
                        
                    }
                    listfree.addFreelancer(new Freelancer(nome, nif, new EnderecoPostal(local, codigoP, localidade), tele, email, lrcFreelancer));
                    lrcFreelancer = new ListaReconhecimentoCompetencias();
                    
                }
            } catch (NoSuchElementException e) {
                System.out.println("Erro a ler o ficheiro listaFreelancers. Verifique o ficheiro .txt em causa.");
            }
            sc.close();
        } catch (FileNotFoundException e) {
            System.out.println("O ficheiro que está a tentar carregar nao existe.");
        }
        return listfree;
    }
    
    public ListaTarefas carregarTarefas() {
        try {
            Scanner sc = new Scanner(new File("listaTarefas.txt"), "utf-8");
            listTar = new ListaTarefas();
            lctTarefa = new ListaCompetencias();
            sc.useDelimiter(";|\n");
            try {
                while (sc.hasNext()) {
                    String referencia = sc.next().trim();
                    String designacao = sc.next().trim();
                    String descInf = sc.next().trim();
                    String descTec = sc.next().trim();
                    int dur = Integer.parseInt(sc.next().trim());
                    double cust = Double.parseDouble(sc.next().trim());
                    String cod1 = sc.next().trim();
                    String cod2 = sc.next().trim();
                    lct = carregarCompetencias();
                    for (int i = 0; i < lct.getCompetencias().size(); i++) {
                        if (lct.getCompetencias().get(i).getCodigo().equals(cod1)
                                || lct.getCompetencias().get(i).getCodigo().equals(cod2)) {
                            lctTarefa.adicionarCompetencia(lct.getCompetencias().get(i));
                            
                        }
                    }
                    try{
                        listTar.addTarefa(new Tarefa(referencia, designacao, descInf, descTec, dur, cust, lctTarefa));
                    }catch(IllegalArgumentException e){
                        System.out.println("Verificar conteudo objeto tarefa. Não é possivel criar uma tarefa vazia");
                    }
                    lctTarefa = new ListaCompetencias();
                }
            } catch (NoSuchElementException e) {
                System.out.println("Erro a ler o ficheiro listaTarefas. Verifique o ficheiro .txt em causa.");
                
            }
            sc.close();
        } catch (FileNotFoundException e) {
            System.out.println("O ficheiro que está a tentar carregar nao existe.");
            
        }
        return listTar;
    }
    
    public ListaCompetencias carregarCompetencias() {
        try {
            Scanner sc = new Scanner(new File("listaCompetencias.txt"), "utf-8");
            lct = new ListaCompetencias();
            sc.useDelimiter(";|\n");
            try {
                while (sc.hasNext()) {
                    String codigo = sc.next().trim();
                    String descBreve = sc.next().trim();
                    String descDetal = sc.next().trim();
                    int v = Integer.parseInt(sc.next().trim());
                    String des = sc.next().trim();
                    boolean caraterct = Boolean.parseBoolean(sc.next().trim());
                    lct.adicionarCompetencia(new CompetenciaTecnica(codigo, descBreve, descDetal, new GrauProficiencia(v, des), caraterct));
                }
            } catch (NoSuchElementException e) {
                System.out.println("Erro a ler o ficheiro listaCompetencias. Verifique o ficheiro .txt em causa.");
                
            }
            sc.close();
        } catch (FileNotFoundException e) {
            System.out.println("O ficheiro que está a tentar carregar nao existe.");
            
        }
        return lct;
    }
}
