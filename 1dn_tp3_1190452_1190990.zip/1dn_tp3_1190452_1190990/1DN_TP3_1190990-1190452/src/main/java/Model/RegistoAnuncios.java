package Model;

import java.util.ArrayList;
import java.util.List;

/**
 * Esta classe permite criar um Registo de Anuncios
 *
 * @author Bruno Pereira
 */
public class RegistoAnuncios {

    /**
     * Lista de anúncios.
     */
    private List<Anuncio> listAnuncios;

    /**
     * Lista de anúncios por seriar.
     */
    private List<Anuncio> listAnunciosPorSeriar;

    /**
     * Constrói uma instância do tipo Registo de anuncios com a lista de
     * anúncios e a lista de anúncios por seriar.
     */
    public RegistoAnuncios() {
        listAnuncios = new ArrayList<>();
        listAnunciosPorSeriar = new ArrayList<>();
    }

    /**
     * Obtenção dos anúncios por seriar de um deterinado colaborador.
     *
     * @param colab
     * @return a lista de anuncios por seriar.
     */
    public List<Anuncio> getAnunciosPorSeriarNaoAutomaticos(Colaborador colab) {
        listAnunciosPorSeriar = new ArrayList<>();
        if (listAnuncios != null) {
            for (int i = 0; i < listAnuncios.size(); i++) {
                if (listAnuncios.get(i).getColab().equals(colab) && listAnuncios.get(i).isPorSeriar() == true) {
                    listAnunciosPorSeriar.add(listAnuncios.get(i));
                }
            }
        }
        return listAnunciosPorSeriar;
    }

    /**
     * Obtenção do anúncio que o utilizador pretende seriar.
     *
     * @param colab
     * @param anuncioID
     * @return o anúncio por seriar.
     */
    public Anuncio getAnuncioPublicadoPor(Colaborador colab, String anuncioID) {
        for (int i = 0; i < listAnunciosPorSeriar.size(); i++) {
            if (listAnunciosPorSeriar.get(i).getColab().equals(colab) && listAnunciosPorSeriar.get(i).getAnuncioID().equals(anuncioID)) {
                return listAnunciosPorSeriar.get(i);
            }
        }
        return null;
    }

    /**
     * Adiciona uma anúncio à lista de anúncios.
     *
     * @param an
     */
    public void addRegistoAnuncios(Anuncio an) {
        listAnuncios.add(an);
    }

}
