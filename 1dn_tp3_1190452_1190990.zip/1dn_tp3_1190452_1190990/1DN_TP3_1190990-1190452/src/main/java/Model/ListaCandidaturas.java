package Model;

import java.util.ArrayList;
import java.util.List;

/**
 * Esta classe permite criar uma Lista de Candidaturas.
 * 
 * @author Ricardo Pereira
 */
public class ListaCandidaturas{
    /**
     * A Lista das Candidaturas.
     */
    private List<Candidatura> list;
    
    /**
     * Constrói uma instância do tipo ListaCandidaturas com o arraylist das candidaturas.
     * 
     */
    public ListaCandidaturas(){
        list = new ArrayList<Candidatura>();
    }
    
    /**
     * Adiciona uma candidatura à lista das candidaturas
     */
    public void addCandidatura(Candidatura cand){
        list.add(cand);
    }
    
    /**
     * Devove a lista de candidaturas.
     * @return list
     */
    public List<Candidatura> getCandidaturas() {
       return list;
    }

    /**
     * Permite imprimir os dados da lista de candidaturas.
     */
    public void imprimirDados() {
        for( Candidatura a : list){
            if(a != null){
                System.out.println(a.toString());
                System.out.println("");
            }   
        }
    }
    
    
}
