package Model;

/**
 * Esta classe permite criar um Freelancer
 *
 * @author Ricardo Pereira
 */
public class Freelancer {

    /**
     * Nome do Freelancer.
     */
    private String nome;
    /**
     * NIF do Freelancer.
     */
    private String nif;
    /**
     * EnderecoPostal do Freelancer.
     */
    private EnderecoPostal end;
    /**
     * Telefone do Freelancer.
     */
    private String telefone;
    /**
     * Email do Freelancer.
     */
    private String email;
    /**
     * Lista de Reconhecimento de Competencias do Freelancer.
     */
    private ListaReconhecimentoCompetencias rc;

    /**
     * Constrói uma instância do tipo Freelancer com nome, nif, endereco postal,
     * telefone, email e lista de competencias tecnicas.
     *
     * @param nome
     * @param nif
     * @param end
     * @param telefone
     * @param email
     * @param rc
     */
    public Freelancer(String nome, String nif, EnderecoPostal end, String telefone, String email, ListaReconhecimentoCompetencias rc) {
        this.nome = nome;
        this.nif = nif;
        this.end = end;
        this.telefone = telefone;
        this.email = email;
        this.rc = rc;
    }

    /**
     * Devolve o nome do Freelancer.
     *
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * Modifica o nome do Freelancer.
     *
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Devolve o Nif do Freelancer.
     *
     * @return the nif
     */
    public String getNif() {
        return nif;
    }

    /**
     * Modifica o Nif do Freelancer.
     *
     * @param nif the nif to set
     */
    public void setNif(String nif) {
        this.nif = nif;
    }

    /**
     * Devolve o Telefone do Freelancer.
     *
     * @return the telefone
     */
    public String getTelefone() {
        return telefone;
    }

    /**
     * Modifica o Telefone do Freelancer
     *
     * @param telefone the telefone to set
     */
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    /**
     * Devolve o Email do Freelancer.
     *
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Modifica o email do Freelancer.
     *
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Devolve a Lista de reconhecimento de Competencias do Freelancer.
     *
     * @return the rc
     */
    public ListaReconhecimentoCompetencias getRc() {
        return rc;
    }

    /**
     * Modifica a Lista de reconhecimento de Competencias do Freelancer.
     *
     * @param rc the rc to set
     */
    public void setRc(ListaReconhecimentoCompetencias rc) {
        this.rc = rc;
    }

    /**
     * Devolve a descrição textual do Freelancer com o nome, nif, endereço
     * postal, telefone e email
     */
    @Override
    public String toString() {
        return String.format("\nNome: %s \nNIF: %s \nEndereço Postal: %s \nTelefone: %s \nEmail: %s", nome, nif, end, telefone, email, getRc());
    }

    /**
     * Calcula a media dos graus de Proficiencia do Freelancer necessários para
     * preencher os requesitos de cada tarefa.
     *
     * @param anu
     * @param c1
     * @return media
     */
    public double calcularMedia(Anuncio anu, Candidatura c1) {
        double total = 0;
        int contador = 0;
        int size1 = anu.getTar().getMetodoListaCT().getCompetencias().size();
        int size2 = c1.getFreelancer().getRc().getListRC().size();
        for (int i = 0; i < size1; i++) {
            for (int p = 0; p < size2; p++) {
                if (anu.getTar().getMetodoListaCT().getCompetencias().get(i).getCodigo().equals(c1.getFreelancer().getRc().getListRC().get(p).getCompT().getCodigo())) {
                    total += c1.getFreelancer().getRc().getListRC().get(p).getGp().getValor();
                    contador++;
                }
            }
        }
        total = total / (contador==0 ? 1 : contador);
        return total;
    }

    /**
     * Calcula o desvio padrão dos graus de Proficiencia do Freelancer
     * necessários para preencher os requesitos de cada tarefa.
     *
     * @param anu
     * @param c1
     * @return desvio
     */
    public double calcularDevioPadrao(Anuncio anu, Candidatura c1) {
        double soma = 0;
        for (int i = 0; i < rc.getListRC().size(); i++) {
            soma = soma + Math.pow((rc.getListRC().get(i).getGp().getValor() - calcularMedia(anu, c1)), 2);
        }
        double variancia = soma / (rc.getListRC().size() - 1);
        return Math.sqrt(variancia);
    }
}
