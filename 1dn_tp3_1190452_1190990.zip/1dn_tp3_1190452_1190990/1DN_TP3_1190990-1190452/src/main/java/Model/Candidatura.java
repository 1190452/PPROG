package Model;

import Utils.Data;

/**
 * Esta classe permite criar uma Candidatura
 * 
 * @author Bruno Pereira
 */
public class Candidatura {

    /**
     * Data da Candidatura.
     */
    private Data dataCandidatura;
    /**
     * O valor pretendido pelo Freelancer para a candidatura.
     */
    private double valorPretendido;
    /**
     * O número de dias necessários para o Freelancer executar a candidatura.
     */
    private int nrDias;
    /**
     * O texto de apresentação do Freelancer para a Candidatura.
     */
    private String txtApresentacao;
    /**
     * O texto de motivacao do Freelancer para a Candidatura.
     */
    private String txtMotivacao;
    /**
     * O freelancer que efetua a candidatura.
     */
    private Freelancer fr;
    /**
     * O ID da candidatura.
     */
    private String candID;

    /**
     * Constrói uma instância do tipo Candidatura com a data, valor pretendido,
     * número de dias, texto de apresentação e de motivação, o Freelancer e o seu ID.
     * @param dataCandidatura
     * @param valorPretendido
     * @param nrDias
     * @param txtApresentacao
     * @param txtMotivacao
     * @param fr
     */
    public Candidatura(Data dataCandidatura, double valorPretendido, int nrDias, String txtApresentacao, String txtMotivacao, Freelancer fr, String candID) {
        this.dataCandidatura = dataCandidatura;
        this.valorPretendido = valorPretendido;
        this.nrDias = nrDias;
        this.txtApresentacao = txtApresentacao;
        this.txtMotivacao = txtMotivacao;
        this.fr = fr;
        this.candID = candID;
    }

    /**
     * @return the dataCandidatura
     */
    public Data getDataCandidatura() {
        return dataCandidatura;
    }

    /**
     * @param dataCandidatura the dataCandidatura to set
     */
    public void setDataCandidatura(Data dataCandidatura) {
        this.dataCandidatura = dataCandidatura;
    }

    /**
     * @return the valorPretendido
     */
    public double getValorPretendido() {
        return valorPretendido;
    }

    /**
     * @param valorPretendido the valorPretendido to set
     */
    public void setValorPretendido(double valorPretendido) {
        this.valorPretendido = valorPretendido;
    }

    /**
     * @return the nrDias
     */
    public int getNrDias() {
        return nrDias;
    }

    /**
     * @param nrDias the nrDias to set
     */
    public void setNrDias(int nrDias) {
        this.nrDias = nrDias;
    }

    /**
     * @return the txtApresentacao
     */
    public String getTxtApresentacao() {
        return txtApresentacao;
    }

    /**
     * @param txtApresentacao the txtApresentacao to set
     */
    public void setTxtApresentacao(String txtApresentacao) {
        this.txtApresentacao = txtApresentacao;
    }

    /**
     * @return the txtMotivacao
     */
    public String getTxtMotivacao() {
        return txtMotivacao;
    }

    /**
     * @param txtMotivacao the txtMotivacao to set
     */
    public void setTxtMotivacao(String txtMotivacao) {
        this.txtMotivacao = txtMotivacao;
    }

    /**
     * @return o Freelancer
     */
    public Freelancer getFreelancer() {
        return fr;
    }

    /**
     * Devolve a descrição textual da Candidatura com o Freelancer, a data da
     * candidatura, o valor pretendido o número de dias, o texto de apresentação
     * e o texto de motivação.
     */
    @Override
    public String toString() {
        return String.format("Freelancer: %s \nData de candidatura: %s%nValor pretendido: %s euros %nNúmero de dias: %d dias "
                + "%nTexto apresentação: %s%nTexto de motivação: %s%n", fr, dataCandidatura, valorPretendido, nrDias, txtApresentacao, txtMotivacao);
    }

    /**
     * @return the candID
     */
    public String getCandID() {
        return candID;
    }

    /**
     * @param candID the candID to set
     */
    public void setCandID(String candID) {
        this.candID = candID;
    }
}
