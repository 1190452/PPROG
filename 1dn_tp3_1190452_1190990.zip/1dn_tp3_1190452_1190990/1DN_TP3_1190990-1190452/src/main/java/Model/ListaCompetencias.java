package Model;

import java.util.ArrayList;
import java.util.List;

/**
 * Esta classe permite criar uma Lista de Competencias.
 *
 * @author Ricardo Pereira
 */
public class ListaCompetencias {

    /**
     * A Lista das Competencias.
     */
    private List<CompetenciaTecnica> listaCompetencias;

    /**
     * Constrói uma instância do tipo ListaCompetencias com o arraylist das
     * Competencias.
     *
     */
    public ListaCompetencias() {
        listaCompetencias = new ArrayList<CompetenciaTecnica>();
    }

    /**
     * Devolve a Lista de Competencias.
     *
     * @return listaCompetencias
     */
    public List<CompetenciaTecnica> getCompetencias() {
        return listaCompetencias;
    }

    /**
     * Adiciona uma competencia à lista de competencias.
     */
    public void adicionarCompetencia(CompetenciaTecnica ct) {
        listaCompetencias.add(ct);
    }

    /**
     * Permite imprimir os dados da lista dos colaboradores.
     */
    public void imprimirDados() {
        if (listaCompetencias != null && listaCompetencias.size()>0) {
            listaCompetencias.stream().filter((a) -> (a != null)).map((a) -> {
                 if(a != null){
                 System.out.println(a.toString());    
                 }
                 System.out.println("");
                return a;
            });
        }else{
            System.out.println("Não existem competências para listar");
        }
    }
}
