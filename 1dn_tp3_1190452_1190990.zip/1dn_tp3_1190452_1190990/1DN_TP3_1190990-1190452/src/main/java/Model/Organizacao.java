package Model;

/**
 * Esta classe permite criar uma Organização
 *
 * @author Bruno Pereira
 */
public class Organizacao {

    /**
     * nome da organização.
     */
    private String nome;
    /**
     * NIF da organização.
     */
    private String NIF;
    /**
     * website da organização.
     */
    private String website;
    /**
     * telefone da organização.
     */
    private String telefone;
    /**
     * email da organização.
     */
    private String email;
    /**
     * lista de colaboradores da organização.
     */
    private ListaColaboradores listaColaboradores;

    /**
     * Constrói uma instância do tipo Organização com o nome, NIF, website,
     * telefone, email e a lista de colaboradores.
     *
     * @param nome
     * @param NIF
     * @param website
     * @param telefone
     * @param email
     * @param listaColaboradores
     */
    public Organizacao(String nome, String NIF, String website, String telefone, String email, ListaColaboradores listaColaboradores) {
        this.nome = nome;
        this.NIF = NIF;
        this.website = website;
        this.telefone = telefone;
        this.email = email;
        this.listaColaboradores = listaColaboradores;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the NIF
     */
    public String getNIF() {
        return NIF;
    }

    /**
     * @param NIF the NIF to set
     */
    public void setNIF(String NIF) {
        this.NIF = NIF;
    }

    /**
     * @return the website
     */
    public String getWebsite() {
        return website;
    }

    /**
     * @param website the website to set
     */
    public void setWebsite(String website) {
        this.website = website;
    }

    /**
     * @return the telefone
     */
    public String getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the listaColaboradores
     */
    public ListaColaboradores getListaColaboradores() {
        return listaColaboradores;
    }

    /**
     * Devolve a descrição textual da Organização com o nome, NIF, website,
     * telefone, email e a lista de colaboradores.
     */
    @Override
    public String toString() {
        return String.format("Nome: %s \nNIF: %s \nWebsite: %s \nTelefone: %s \nEmail: %s", nome, NIF, website, telefone, email);
    }

}
