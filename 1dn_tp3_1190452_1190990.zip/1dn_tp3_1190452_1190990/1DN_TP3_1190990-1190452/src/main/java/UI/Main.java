package UI;

import Model.Anuncio;
import Model.Candidatura;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Bruno Pereira
 */
public class Main {

    public static void main(String[] args) {

        Scanner ler = new Scanner(System.in);

        SeriarAnuncioUI ui = new SeriarAnuncioUI("UC10");

        List<Anuncio> anunciosPorSeriar = null;
        List<Candidatura> candidaturas = null;
        String anuncioID = null;

        try {

            mostrarMenu();
            System.out.println("\nIntroduza o exercício que pretende executar");
            int n = ler.nextInt();
            while (n != 0) {

                switch (n) {
                    case 1:
                        anunciosPorSeriar = ui.getAnunciosPorSeriarNaoAutomatico();
                        System.out.println("######Impressão da lista de Anúncios por Seriar######");
                        listarForEach(anunciosPorSeriar);
                        if (ui.getAnunciosPorSeriarNaoAutomatico().isEmpty()) {
                            System.out.println("Este colbarodar não possui anúncios por seriar");
                        }
                        break;
                    case 2:
                        System.out.println("\n######Escolha o Anúncio que pretende######");
                        anuncioID = ler.next();
                        candidaturas = ui.getCandidaturas(anuncioID);
                        break;
                    case 3:
                        mostrarCriteriosSeriacao();
                        System.out.println("\n######Escolha o método de seriação que pretende utilizar (1 ou 2)######");
                        int tipoSeriacao = ler.nextInt();
                        ui.seriarCandidaturas(candidaturas, tipoSeriacao);
                        System.out.println("Processo de Seriação Concluido!");
                        ui.setPorSeriar(anuncioID);
                        break;

                    case 4:
                        System.out.println("\n######Impressão da Lista de Candidaturas após a sua seriação######");
                        listarForEach1(candidaturas);
                        System.out.println("######Impressão da lista de Anúncios por Seriar######");
                        listarForEach3(ui.getAnunciosPorSeriarNaoAutomatico());
                        if (ui.getAnunciosPorSeriarNaoAutomatico().isEmpty()) {
                            System.out.println("\nEste colaborador já não possui mais anúncios para seriar!");
                        }
                    default:
                        break;
                }
                mostrarMenu();
                System.out.println("\nIntroduza o próximo exercício");
                n = ler.nextInt();

            }

        } catch (NullPointerException e) {
            System.out.println("Lista de Anúncios encontra-se vazia");

        } catch (InputMismatchException e) {
            System.out.println("Introduziu mal os dados. Volte a correr o programa de novo!");
        }

    }

    private static void listarForEach(List<Anuncio> anunciosPorSeriar) {
        anunciosPorSeriar.forEach((anuncio) -> {
            System.out.println("\n" + anuncio.toString());
        });
    }

    private static void listarForEach1(List<Candidatura> candidaturas) {
        for (Candidatura cand : candidaturas) {
            System.out.println("\n" + cand.toString());
        }
    }

    private static void listarForEach3(List<Anuncio> anuncios2) {
        anuncios2.forEach((an) -> {
            System.out.println("\n" + an.toString());
        });
    }

    private static void mostrarMenu() {
        System.out.println("\n");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|      Exercício      |                              Enunciado                                 |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          0          | Sair da Aplicação                                                      |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          1          | Obter a lista de anúncios por Seriar e sua impressão                   |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          2          | Escolher o anúncio que pretende para seriar a lista de candidaturas    |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          3          | Mostrar Critérios de seriação e escolha do processo                    |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("|          4          | Mostrar a lista de Candidaturas Seriada                                |");
        System.out.println("|---------------------|------------------------------------------------------------------------|");

    }

    private static void mostrarCriteriosSeriacao() {
        System.out.println("|---------------------|------------------------------------------------------------------------|");
        System.out.println("| Critérios do Processo de Seriação 1       || Critérios do Processo de Seriação 2             |");
        System.out.println("|---------------------|---------------------||-------------------------------------------------|");
        System.out.println("| • Maior média dos níveis de proficiência  || • Maior média dos níveis de proficiência        |");
        System.out.println("| em cada uma das competências técnicas     || em cada uma das competências técnicas           |");
        System.out.println("| exigidas para a tarefa;                   || exigidas para a tarefa;                         |");
        System.out.println("|---------------------|---------------------||-------------------------------------------------|");
        System.out.println("|                                           || • Menor desvio padrão dos níveis de proficiência|");
        System.out.println("| • Preço mais baixo;                       || em cada uma dascompetências técnicas exigidas   |");
        System.out.println("|                                           || para a tarefa;                                  |");
        System.out.println("|---------------------|---------------------||-------------------------------------------------|");
        System.out.println("| • Proposta registada mais cedo;           || • Preço mais baixo;                             |");
        System.out.println("|---------------------|---------------------||-------------------------------------------------|");
        System.out.println("|                                           || • Proposta registada mais cedo;                 |");
        System.out.println("|---------------------|---------------------||-------------------------------------------------|");

    }
}
