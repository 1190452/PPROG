package UI;

import Controller.SeriarAnuncioController;
import java.util.List;
import Model.Anuncio;
import Model.Candidatura;
import Model.CarregarFicheirosTexto;
import Model.ListaCandidaturas;
import Model.ListaColaboradores;
import Model.ListaFreelancers;
import Model.ListaTarefas;
import Model.RegistoAnuncios;
import Model.RegistoOrganizacoes;

/**
 *
 * @author Bruno Pereira
 */
public class SeriarAnuncioUI {

    /**
     * Objeto referente à classe controller.
     */
    private SeriarAnuncioController seriar_controller;
    /**
     * Objeto referente à classe carregar ficheiros.
     */
    private CarregarFicheirosTexto cf;

    /*
    *Constrói uma instância do tipo SeriarAnuncioUI
     */
    public SeriarAnuncioUI() {
        seriar_controller = new SeriarAnuncioController("");
        cf = new CarregarFicheirosTexto();
    }

    /*
    * Constrói uma instância do tipo SeriarAnuncioUi com a designação.
     */
    public SeriarAnuncioUI(String designacao) {
        cf = new CarregarFicheirosTexto();
        ListaColaboradores lc = cf.carregarListaColaborador();
        ListaTarefas lt = cf.carregarTarefas();
        ListaFreelancers lf = cf.carregarListaFreelancer();
        ListaCandidaturas lcand = cf.carregarListaCandidaturas();
        RegistoAnuncios lAnun = cf.carregarListaAnuncios();
        RegistoOrganizacoes lorg = cf.carregarOrganizacoes();
        seriar_controller = new SeriarAnuncioController(designacao, lt, lf, lcand, lAnun, lc, lorg);
        
    }

    /**
     * Objeto referente à classe controller.
     */
    public List<Anuncio> getAnunciosPorSeriarNaoAutomatico() {
        return seriar_controller.getAnunciosPorSeriarNaoAutomatico();
    }

    /**
     * Objeto referente à classe controller.
     *
     * @param anuncioID
     * @return
     */
    public List<Candidatura> getCandidaturas(String anuncioID) {
        return seriar_controller.getCandidaturas(anuncioID);
    }

    /**
     * Seria a lista de candidaturas.
     *
     * @param candidaturas
     * @param tipoSeriacao
     */
    public void seriarCandidaturas(List<Candidatura> candidaturas, int tipoSeriacao) {
        seriar_controller.seriarCandidaturas(candidaturas, tipoSeriacao);
    }

    /**
     * set da variável booleana porSeriar através do anúncioID.
     *
     * @param anuncioID
     */
    public void setPorSeriar(String anuncioID) {
        if (anuncioID != null) {
            seriar_controller.setPorSeriar(anuncioID);
        }

    }

}
